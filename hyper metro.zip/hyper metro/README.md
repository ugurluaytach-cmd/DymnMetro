# HyperMetro

**Metro esintili, kendi kutucuk düzeni, renkleri, duvar kâğıtları ve ikon stili olan bir Android launcher.** HyperMetro, bakışta bilgi veren kutucuk ana ekran fikrini Android için yeniden yorumlar; başka bir launcher'ı piksel piksel kopyalamayı amaçlamaz.

> Bağımsız bir topluluk projesidir. Microsoft, Google veya herhangi bir telefon üreticisiyle bağlantısı, sponsorluğu ya da resmî onayı yoktur. “Metro” yalnızca görsel esin kaynağını tarif eder; proje kendi adını ve uygulamasını kullanır.

**English:** [README in English](README.en.md)

## Ön izleme

![HyperMetro karo düzenleme ekranı](docs/screenshots/hypermetro-tile-editor.png)

*Proje sahibinin test sürümünden alınmış karo düzenleme ekranı. Görseldeki uygulama ikonları Android ve cihazda yüklü uygulamalar tarafından sağlanır.*

## Neler sunuyor?

- Android varsayılan ana ekranı olarak seçilebilme.
- Uygulamaları kutucuk ana ekrana sabitleme, kutu boyutunu değiştirme ve kutuları düzenleme.
- Birden fazla ana ekran sayfası ve uygulama sabitlerken/hedef sayfaya taşırken sayfa seçimi.
- Arama ve alfabetik gezinme içeren uygulama çekmecesi.
- Android'in uygulama ikonları veya HyperMetro'nun çizgisel ikon görünümü.
- Renk, saydamlık, tema, duvar kâğıdı ve grid sütun sayısı seçenekleri.
- İsteğe bağlı saat ve takvim kutuları.
- Uygulamaları klasörlerde toplama.

Kutu başına renk ve bazı düzenleme akışları gerçek cihazlarda doğrulanmaya devam ediyor. Güncel durum, öncelikler ve bilinen işler için [ROADMAP.md](ROADMAP.md) dosyasına bak. Proje geliştirme aşamasında; Google Play için son sürüm değildir.

## Derleme

### Gereksinimler

- Android SDK Platform 36 ve Build Tools 36.1.0 içeren Android Studio
- JDK 21 (Gradle daemon araç zinciri Java 21 olarak ayarlı)
- Kurulum için Android 8.0 (API 26) veya üzeri

Windows'ta proje klasöründen:

```powershell
\.\gradlew.bat assembleDebug
```

macOS veya Linux'ta:

```sh
./gradlew assembleDebug
```

Debug APK şu konuma çıkar: `app/build/outputs/apk/debug/app-debug.apk`. Test cihazına kurup Android ayarlarından HyperMetro'yu varsayılan Ana ekran uygulaması seçerek launcher olarak deneyebilirsin. Varsayılan launcher yapmadan normal uygulama gibi de açabilirsin.

## Proje notları

- Mevcut uygulama kimliği `com.example.hypermetro`; mağaza yayını öncesinde kalıcı bir kimlik seçilmeli.
- HyperMetro Android ana ekranı ve uygulama çekmecesi arayüzünü sağlar. Uygulamaları başlatma ve sistem pencereleri Android tarafından yönetilir.
- Masaüstü modu sonraki yol haritası aşamasında; önce telefon ve tablet temelleri tamamlanacak.
- `docs/DESIGN-LANGUAGE.md` taslak görsel yönlendirme içerir; uygulama ile her noktada aynı olmayabilir.

## Esin kaynağı ve atıf

HyperMetro, Metro tasarım dönemindeki kutucuk tabanlı ve bakışta bilgi veren ana ekran fikrinden esinlenir. Adı, arayüzü ve çizgisel ikonları bu proje için geliştirilir. Projeye Microsoft veya Apple logoları ya da özel ikon paketleri eklenmemiştir. Ekran görüntülerindeki yerel ikonlar, yakalama cihazına kurulu Android uygulamalarından gelir.

Kaynak ağacında Dima / Dymn Studio atıflı [`LICENSE-DymnMetro-MIT`](LICENSE-DymnMetro-MIT) dosyası bulunur. Bu lisansın kapsadığı kodu yeniden dağıtırken lisansı ve atfı koru. Değiştirilmiş bir sürümü yayınlamadan önce dosya geçmişini ve üçüncü taraf varlıkların lisanslarını kontrol et; upstream çalışmaları yalnızca HyperMetro tarafından yazılmış gibi sunma.

## Yol haritası

Önceliklendirilmiş plan için [ROADMAP.md](ROADMAP.md): önce güvenilirlik sorunları ve launcher'ın günlük kullanım temelleri, sonra görsel tutarlılık ve gelişmiş özellikler; masaüstü modu daha sonraki aşamada.

## Katkı

Hata bildirimleri, farklı cihazlarda gözlemler ve küçük, odaklı katkılar memnuniyetle karşılanır. Sorun bildirirken Android sürümünü, cihaz modelini, tekrar üretme adımlarını ve gerekiyorsa ekran görüntüsünü ekle. Kişisel bildirimleri, kişileri veya özel bilgileri gösteren görselleri paylaşma.
