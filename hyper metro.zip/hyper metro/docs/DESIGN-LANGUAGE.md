---
name: dymnmetro-tasarim-dili
description: DymnMetro launcher'ında UI yazarken kullan: Metro'nun düz, tipografi odaklı dilini HyperOS'un yumuşak köşe, derinlik ve akıcı hareketiyle birleştiren karo, renk, yazı tipi ve animasyon kuralları.
---

# DymnMetro Tasarım Dili

Fikir: Metro'nun **düz renk + tipografi + net grid** yapısı, HyperOS'un **yumuşak köşe + hafif derinlik + akışkan hareketi** ile birleşir. Ne düz bir Metro kopyası ne de Material kartı. İkisinin arası.

## 1. Ne nereden gelir

| Metro'dan | HyperOS'tan |
|---|---|
| Düz, doygun accent renk | Yumuşak, sürekli köşeler |
| Büyük, ince (light) sayılar ve başlıklar | Çok hafif derinlik (gölge, iç parlama) |
| Sıkı grid, az boşluk | Yaylanan (spring) animasyonlar |
| Küçük harfli sayfa başlıkları ("apps") | Sakin, dengeli renk geçişleri |
| Karo = canlı içerik | Cam hissi (yarı saydam yüzey) |

## 2. Karo kuralları

- Grid: 4 sütun. Boyutlar: 1x1 (küçük), 2x2 (orta), 4x2 (geniş), 4x4 (büyük).
- Karo arası boşluk: 6dp. Metro'nun sıkı hissini korur.
- Köşe: küçük 16dp, orta ve üstü 22dp. Mümkünse sürekli köşe (squircle) kullan. Compose'ta yerleşik yok, `androidx.graphics:graphics-shapes` ile çizilir.
- Dolgu: accent rengi, alttan %8 koyulaşan çok hafif dikey gradient. Gradient fark edilmemeli, sadece düz görünümü canlandırmalı.
- Kenar: 1dp iç çizgi, beyaz %12. Karoya ince bir "cam kenarı" verir.
- Gölge: yok ya da çok yumuşak (alpha %10 altı). Ağır gölge Metro'yu bozar.
- Cam varyantı: duvar kağıdı modunda yarı saydam dolgu + aynı iç çizgi. Gerçek arka plan bulanıklığı Compose'ta kısıtlı (`Modifier.blur` içeriği bulanıklaştırır, arkadaki zemini değil). Gerçek blur için Android 12+ pencere blur'ı gerekir, ihtiyaç olunca ayrıca değerlendir.
- Karo içinde izin uyarısı yazma ("Enable permission in settings" gibi). Boş karo sakin bir yer tutucu gösterir, izin isteği onboarding'de tek seferde yapılır.

## 3. Renk

- Varsayılan tema koyu. Zemin yaklaşık `#0B0F14`.
- Metin: ana %100 beyaz, ikincil %70.
- Accent paleti ve Monet (dinamik renk) seçeneği ayarlarda. Accent üstü metin kontrastı en az 4.5:1.
- Tek bir ekranda en fazla 1 accent + nötr tonlar. Her karo ayrı renk olmasın.

## 4. Tipografi

- Büyük sayılar ve başlıklar: Light (300). Karo etiketi: Medium (500). Gövde: Regular (400).
- Sayfa başlıkları küçük harf.
- Yazı tipi: Inter, Manrope veya Outfit (açık lisans, OFL). **Segoe kullanılmaz** (Microsoft'un). MiSans'ı ancak lisansı kontrol edilince ekle.
- Yazı boyutu sistem ölçeğini (font scale) takip eder.

## 5. Hareket

- Basma: karo dokunulan noktaya doğru hafifçe yatar (Metro tilt, en fazla 6 derece) ve 0.97'ye küçülür.
- Yay (spring): `dampingRatio ≈ 0.8`, `stiffness ≈ 400`. Süre hissi 300ms'yi geçmesin.
- Canlı karo çevrilmesi: her karo farklı gecikmeyle (rastgele 6 ile 12 sn). Hepsi aynı anda dönmesin.
- Sayfa geçişi: Metro turnstile benzeri, ama yumuşak spring ile.
- Sistem animasyonları kapalıysa ya da "hareketi azalt" açıksa tüm hareketi kıs.
- Anlamlı yerlerde hafif haptic (karo yeniden düzenleme, sürükleme başlangıcı).

## 6. Erişilebilirlik

- Dokunma hedefi en az 48dp.
- Kontrast en az 4.5:1 (metin), 3:1 (büyük metin ve ikon).
- TalkBack için her karoda anlamlı `contentDescription`.
- Büyük yazı boyutunda karo metni taşmaz, kısalır ve sığar.

## 7. Yasaklar (hukuki ve marka)

- "Windows Phone", Windows logosu, Segoe ve Microsoft görsellerini kullanma.
- Adlarda "Metro" jenerik kalabilir, ama marka izlenimi verme. Kendi adımız ve logomuz.
- Başka projeden kod alırsan lisansını (MIT, Apache 2.0) ve telif notunu koru.

## 8. Çalışma kuralları (bu proje)

- Küçük, izole, geri alınabilir adımlar. Büyük yeniden yazım yok.
- Mevcut bölümleri silme ya da kısaltma. Yeni bir şey eklerken eskisine dokunma.
- Her bileşen için Compose Preview yaz (açık ve koyu, büyük yazı boyutu).
- Araç sürümleri: AGP 9.2.1, Kotlin 2.2.10, minSdk 26.
