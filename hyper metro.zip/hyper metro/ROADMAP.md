# HyperMetro — Ürün Yol Haritası

**Ürün durumu:** Android'de çalışan, kullanıcısının günlük kullandığı kişiselleştirilebilir launcher prototipi. Öncelik yeni ve gösterişli özellikler eklemekten önce mevcut deneyimi güvenilir hâle getirmek ve modern launcher'larda beklenen temel işleri tamamlamaktır.

**Ürün amacı:** Android ana ekranını Metro'dan esinlenen canlı kutucuklar, klasörler, sayfalar, duvar kâğıdı ve özgün ikon seçenekleriyle kişiselleştirmek. HyperMetro kendi markası ve görsel diliyle ayrışır; Microsoft/Apple'a ait logo veya ikonları kullanmaz.

## Öncelik ilkeleri

1. Günlük kullanımda hata veya veri kaybı yaratabilecek sorunları çöz.
2. Ana ekran, uygulama çekmecesi, klasör ve arama gibi launcher'ın temel işlerini tamamla.
3. Widget, bildirim rozeti ve gelişmiş özelleştirmeyi temel deneyim oturduktan sonra ekle.
4. Masaüstü modu ürün fikri olarak korunur; telefon ve tablet deneyimi sağlamlaşmadan başlatılmaz.
5. Animasyon ve arka plan işleri isteğe bağlı olmalı; bellek, pil ve düşük seviye cihazlar gözetilmeli.

## Mevcut temel

- [x] Android HOME/launcher olarak seçilebilme ve uygulamaları başlatma
- [x] Uygulama çekmecesi, ada göre arama, alfabetik liste ve harf şeridi
- [x] Ana ekran kutuları, 4/5/6/8 sütun seçimi, kutu boyutları ve aynı sayfada sürükleyerek düzenleme
- [x] Birden fazla ana ekran sayfası; sayfaya uygulama sabitleme ve hedef sayfa seçerek taşıma
- [x] Açık klasör oluşturma modu ve klasör adı verme; klasörü yeniden adlandırma
- [x] Android uygulama ikonları ile HyperMetro çizgisel ikonları arasında seçim
- [x] Genel vurgu rengi, geniş renk paleti, duvar kâğıdı seçimi ve kişisel fotoğraf kaydetme
- [x] Karo saydamlığı ve saat/takvim karo temeli
- [ ] **Karo başına renk kullanıcı tarafından gerçek cihazda doğrulanmadı.** Ayarlar ekranındaki tek-karo seçimini ve renk kalıcılığını ilk iş olarak doğrula.

## Eylem planı

### P0 — Mevcut deneyimi güvenilir kıl

Bu faz tamamlanmadan yeni büyük özellik başlatma.

- [ ] Ayarlar > kutu renkleri ekranında tek bir karoyu seçip rengini değiştir; aynı sayfada ikinci karoya farklı renk ata.
- [ ] Renklerin ana ekranda, klasörlerde ve sayfa değişiminde doğru kaldığını doğrula.
- [ ] `Varsayılan` seçeneğinin yalnızca seçilen karonun özel rengini kaldırdığını doğrula.
- [ ] Renklerin uygulama kapanıp açıldığında ve cihaz yeniden başlatıldığında korunduğunu doğrula.
- [ ] Taşıma, klasör ve renk düzenleme modlarını görsel olarak birbirinden ayır; yanlış moda dokunmayla girilmesini önle.
- [ ] Boş hücreye taşıma, dolu hücreyle yer değiştirme, klasöre ekleme/çıkarma ve klasörün son üyelerini kaldırma akışlarını uçtan uca düzelt.
- [ ] Uygulama kaldırılınca veya güncellenince sabitlenmiş karo/klasör durumunu temizle ya da güncelle.
- [ ] Telefon üzerinde farklı karo boyutu, sütun, tema, saydamlık ve duvar kâğıdı kombinasyonlarını dene.

**Çıkış ölçütü:** Düzen veya renk değişikliği kaybolmuyor; taşıma/klasör oluşturma yalnızca seçilen modda çalışıyor; uygulama kaldırma sonrası bozuk/ölü karo bırakmıyor.

### P1 — Launcher'ın günlük kullanım temelleri

- [ ] Klasör yönetimini tamamla: aç/kapat, yeniden adlandır, uygulama çıkar, son uygulama çıkınca klasörü kaldır; isim boşluğu ve yinelenen isimleri yönet.
- [ ] Uygulama çekmecesi için sıralama seçenekleri ve gizli uygulamalar listesi ekle.
- [ ] Arama için sonuç bulunamadı durumu, temizleme düğmesi ve Türkçe karakter/büyük-küçük harf davranışını düzelt.
- [ ] Ana sayfa yönetimi ekle: sayfa adı, yeniden sıralama, silme ve varsayılan açılış sayfası. Son sayfa ve içeriği için güvenli onay/taşıma davranışı belirle.
- [ ] Uygulama uzun-bas menüsünü tamamla: sabitle/kaldır, uygulama bilgisi, kaldırma ve varsa Android uygulama kısayolları.
- [ ] Temel hareketleri ayarlanabilir yap: uygulama çekmecesini açma, arama ve sayfa geçişi; çakışan hareketlere izin verme.
- [ ] Ekran yönü, tablet ve farklı yoğunluk/ekran boyutlarında grid taşması ve dokunma hedeflerini çöz.
- [ ] Varsayılan launcher seçme/geri dönme akışını ve uygulama ilk açılışını anlaşılır hâle getir.

**Çıkış ölçütü:** Kullanıcı uygulama bulabiliyor, sabitleyip kaldırabiliyor, sayfalarını ve klasörlerini yönetebiliyor; launcher varsayılan yapılmadığında da düzgün çalışıyor.

### P2 — Kişiselleştirme ve görsel tutarlılık

- [ ] Karo başına renk özelliğini P0 doğrulamasından sonra tamamlandı olarak işaretle; tüm karo boyutlarında ve klasör karo renginde tutarlılığı sağla.
- [ ] Android ve HyperMetro ikon görünümünü ana ekran, çekmece, klasör ve arama sonuçlarında tutarlı uygula.
- [ ] HyperMetro ikon ailesini yaygın uygulama türlerini kapsayacak şekilde genişlet; eşlemeyi uygulama kimliğiyle yap, eşleşme yoksa sistem ikonunu göster.
- [ ] Küçük, orta, geniş ve büyük karolarda ikon ölçekleme/kırpma ve etiket okunurluğunu iyileştir.
- [ ] Saydamlık ve karo rengi üzerinde açık/koyu duvar kâğıtlarında metin kontrastını koru.
- [ ] Daha sonra isteğe bağlı olarak kullanıcı ikon dosyası atama ve çekmeceye kategori/klasör ekleme değerlendir.

**Çıkış ölçütü:** Özelleştirme seçenekleri her ekranda aynı sonucu verir; bilinmeyen uygulamalar güvenli biçimde Android ikonuna döner; metin ve ikonlar seçilen zeminde okunur.

### P3 — Modern launcher'larda beklenen gelişmiş özellikler

Bu fazda her özellik ayrı ayar ve kapatma seçeneğiyle, performans ölçülerek eklenir.

- [ ] Android widget seçicisi ve ana ekrana widget yerleştirme/yeniden boyutlandırma desteği.
- [ ] Bildirim rozetleri: Android'in izin ve erişilebilirlik sınırlarına uygun, açık kullanıcı tercihiyle.
- [ ] Yedekleme/dışa aktarma: sayfalar, klasörler, karo boyutları ve görünüm tercihleri.
- [ ] Geri yükleme önizlemesi; bulunmayan uygulamaları atlama ve mevcut düzeni ezmeden önce onay.
- [ ] Takvim karosunda izin açıklaması, izin reddi ve veri yok durumları.
- [ ] Hava durumu/canlı karo gibi özelliklerden önce veri kaynağı, gizlilik, ağ ve pil maliyetini netleştir.
- [ ] Hareketli duvar kâğıtlarını ancak bellek/pil sınırları ve arka planda durdurma davranışı belirlendikten sonra değerlendir.

**Çıkış ölçütü:** Gelişmiş özellikler isteğe bağlıdır; kapatıldığında temel launcher deneyimini etkilemez; düşük bellekli cihazlarda sorun yaratmaz.

### P4 — Erişilebilirlik, sağlamlık ve beta hazırlığı

- [ ] TalkBack açıklamaları, klavye/fare odağı, yeterli dokunma alanı ve kontrast denetimi.
- [ ] Türkçe ve İngilizce arayüz; kullanıcıya görünen metinleri kaynak dosyalarına taşı.
- [ ] Kurulum/kaldırma, yeniden başlatma, launcher değiştirme, izin reddi ve sistem tema değişimi senaryolarını doğrula.
- [ ] Soğuk açılış, ikon belleği, kaydırma akıcılığı, pil ve düşük RAM cihaz performansını ölç.
- [ ] Uygulama adı, logo, paket kimliği ve sürüm numarası stratejisini ürün kimliğine göre tamamla.
- [ ] Kaynak kodu/ikon lisansları, gizlilik politikası, izin açıklamaları, destek kanalı ve mağaza materyallerini hazırla.
- [ ] Debug APK yerine imzalı release APK/AAB; farklı üreticilerde kapalı beta ve hata geri bildirimi.
- [ ] Google Play'in hedef API ve yayın koşullarını yayın öncesinde tekrar doğrula.

**Çıkış ölçütü:** Temiz kurulumdan güncellemeye kadar temel akışlar çalışır; kullanıcı verisi kaybolmaz; imzalı beta paylaşılabilir.

### P5 — Masaüstü modu: sonraki ürün aşaması

Telefon/tablet temel fazları ve beta sağlamlığı tamamlanınca başla.

- [ ] Harici ekran ve masaüstü benzeri mod algılandığında ayrı, geniş ekran Metro çalışma alanı tasarla.
- [ ] Fare/trackpad hover ve sağ tık, klavye odağı/kısayolları ve yoğun bilgi düzeni desteği ekle.
- [ ] Geniş ekranda karo grupları, hızlı başlatma ve uygulama arama deneyimini doğrula.
- [ ] Masaüstü pencerelerini Android/sistem yönetir; HyperMetro ana ekranı ve başlatma deneyimini sunar. Samsung DeX ve Android masaüstü pencereleme farklı cihazlarda ayrıca test edilir.

**Çıkış ölçütü:** Telefon görünümü bozulmadan harici ekran/DeX/masaüstü benzeri ortamda kullanılabilir ayrı düzen.

## Bilerek sonraya bırakılanlar

- Sayfalar arası uygulama sürükleme: mevcut ürün yaklaşımında hedef sayfayı listeden seçme korunuyor.
- Otomatik kategori klasörleri: kullanıcı uygulamaları izni olmadan taşınmaz; ileride öneri olarak sunulabilir.
- Her uygulamaya özel ikon dosyası ve üçüncü taraf ikon paketi desteği: önce yerleşik ikon ailesi ve tutarlılık.
- Canlı karo akışları ve hareketli arka plan: pil, gizlilik ve bellek etkisi ölçülmeden varsayılan yapılmaz.
- Microsoft/Windows Phone veya Apple'a ait logolar ve birebir ikonlar HyperMetro varlığı olarak dağıtılmaz.

## Uygulama sırası

**P0 mevcut sorunları doğrula ve kapat → P1 günlük launcher temelleri → P2 görsel tutarlılık/özelleştirme → P3 widget/rozet/yedekleme gibi gelişmiş özellikler → P4 erişilebilirlik ve kapalı beta → P5 masaüstü modu.** Her fazın çıkış ölçütü tamamlanmadan sonraki fazı başlatma.

## Yayın öncesi teknik notlar

- Mevcut uygulama kimliği `com.example.hypermetro`; Play yayını öncesinde kalıcı ürün kimliği seçilmeli.
- Kaynakta `LICENSE-DymnMetro-MIT` bulunuyor. Başlangıç kodunun kaynağı ve lisans bildirimleri korunmalı; türetilen kod/varlıkların dağıtım uygunluğu yayın öncesi incelenmeli.
- Release imzası, hedef API, gizlilik beyanı ve mağaza politikaları yayın tarihinde yeniden doğrulanmalı.
