pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// Çalışma adı. Marka kararı verilince burası ve paket adı birlikte değişir.
rootProject.name = "HyperMetro"
include(":app")
