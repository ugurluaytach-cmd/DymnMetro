package com.example.hypermetro.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hypermetro.ui.theme.MetroTheme
import java.util.Locale
import kotlinx.coroutines.launch

/** Listede görünen uygulama. Android'e bağlı değil, Preview'da sahte veriyle denenebilir. */
data class AppEntry(val key: String, val label: String)

private sealed interface AppRow {
    val id: String

    data class Header(val letter: String) : AppRow {
        override val id: String = "header_$letter"
    }

    data class App(val entry: AppEntry) : AppRow {
        override val id: String = "app_${entry.key}"
    }
}

/**
 * Tüm uygulamalar: harf başlıkları, sağda alfabe şeridi, üstte arama.
 * [entries] ada göre sıralı gelmeli (AppRepository.loadApps böyle verir).
 */
@Composable
fun AppsScreen(
    entries: List<AppEntry>,
    iconFor: @Composable (AppEntry) -> ImageBitmap?,
    onAppTap: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
    onAppLongPress: (AppEntry) -> Unit = {},
    hyperMetroIcons: Boolean = true,
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    val searching = query.isNotBlank()

    val rows = remember(entries, query) {
        if (searching) {
            entries
                .filter { it.label.contains(query.trim(), ignoreCase = true) }
                .map { AppRow.App(it) }
        } else {
            buildRows(entries)
        }
    }
    // Her harfin listedeki ilk satırı: şeride dokununca oraya kayılır.
    val headerIndex = remember(rows) {
        rows.withIndex()
            .filter { it.value is AppRow.Header }
            .associate { (it.value as AppRow.Header).letter to it.index }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .systemBarsPadding()
            // Arama kutusuna yazarken klavye listeyi ezmesin, liste klavyenin üstünde kalsın.
            .imePadding(),
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            BasicText(
                text = "apps",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp),
                style = typography.pageTitle.copy(color = colors.onBackground),
            )
            SearchField(
                query = query,
                onQueryChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
            )
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 0.dp, end = 40.dp, top = 8.dp, bottom = 24.dp),
            ) {
                items(rows, key = { it.id }) { row ->
                    when (row) {
                        is AppRow.Header -> LetterHeader(row.letter)
                        is AppRow.App -> AppRowItem(
                            entry = row.entry,
                            icon = iconFor(row.entry),
                            hyperMetroIcons = hyperMetroIcons,
                            onTap = { onAppTap(row.entry) },
                            onLongPress = { onAppLongPress(row.entry) },
                        )
                    }
                }
            }
        }

        if (!searching && headerIndex.isNotEmpty()) {
            LetterStrip(
                letters = headerIndex.keys.toList(),
                onLetterTap = { letter ->
                    headerIndex[letter]?.let { index ->
                        scope.launch { listState.animateScrollToItem(index) }
                    }
                },
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 6.dp),
            )
        }
    }
}

private fun buildRows(entries: List<AppEntry>): List<AppRow> {
    val rows = mutableListOf<AppRow>()
    for ((letter, group) in entries.groupBy { letterOf(it.label) }) {
        rows.add(AppRow.Header(letter))
        group.forEach { rows.add(AppRow.App(it)) }
    }
    return rows
}

private fun letterOf(label: String): String {
    val first = label.trim().firstOrNull() ?: return "#"
    return if (first.isLetter()) first.toString().uppercase(Locale.getDefault()) else "#"
}

@Composable
private fun SearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    val shape = RoundedCornerShape(26.dp)

    BasicTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        textStyle = typography.body.copy(color = colors.onBackground, fontSize = 16.sp),
        cursorBrush = SolidColor(colors.accent),
        modifier = modifier
            .border(1.dp, colors.onBackground.copy(alpha = 0.35f), shape)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        decorationBox = { innerTextField ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (query.isEmpty()) {
                    BasicText(
                        text = "search apps",
                        style = typography.body.copy(
                            color = colors.onBackgroundSecondary,
                            fontSize = 16.sp,
                        ),
                    )
                }
                innerTextField()
            }
        },
    )
}

@Composable
private fun LetterHeader(letter: String) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography

    Box(
        modifier = Modifier
            .padding(start = 12.dp, top = 12.dp, bottom = 4.dp)
            .size(40.dp)
            .border(1.dp, colors.onBackground.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center,
    ) {
        BasicText(
            text = letter,
            style = typography.pageTitle.copy(
                color = colors.onBackground,
                fontSize = 24.sp,
                fontWeight = FontWeight.Light,
            ),
        )
    }
}

@Composable
private fun AppRowItem(
    entry: AppEntry,
    icon: ImageBitmap?,
    hyperMetroIcons: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
) {
    val currentOnTap by rememberUpdatedState(onTap)
    val currentOnLongPress by rememberUpdatedState(onLongPress)
    var pressed by remember { mutableStateOf(false) }
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (pressed) MetroTheme.colors.onBackground.copy(alpha = 0.1f) else Color.Transparent,
            )
            .semantics(mergeDescendants = true) {
                role = Role.Button
                onClick { currentOnTap(); true }
                onLongClick { currentOnLongPress(); true }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { currentOnTap() },
                    onLongPress = { currentOnLongPress() },
                )
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(icon = icon, size = 44.dp, appLabel = entry.label, hyperMetroStyle = hyperMetroIcons)
        Spacer(Modifier.width(16.dp))
        BasicText(
            text = entry.label,
            style = typography.body.copy(color = colors.onBackground, fontSize = 18.sp),
            maxLines = 1,
        )
    }
}

@Composable
private fun LetterStrip(
    letters: List<String>,
    onLetterTap: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    val shape = RoundedCornerShape(16.dp)

    Column(
        modifier = modifier
            .fillMaxHeight(0.7f)
            .width(28.dp)
            .border(1.dp, colors.onBackground.copy(alpha = 0.3f), shape),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        for (letter in letters) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clickable { onLetterTap(letter) },
                contentAlignment = Alignment.Center,
            ) {
                BasicText(
                    text = letter,
                    style = typography.caption.copy(color = colors.onBackground),
                )
            }
        }
    }
}

private val PreviewEntries = listOf(
    "Calendar", "Camera", "Chrome", "Clock", "Contacts", "Drive", "Files", "Gmail",
    "Maps", "Messages", "Phone", "Photos", "Settings", "Store",
).mapIndexed { i, name -> AppEntry("preview_$i", name) }

@Preview(name = "Apps dark", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun AppsScreenDarkPreview() {
    MetroTheme(darkTheme = true) {
        AppsScreen(entries = PreviewEntries, iconFor = { null }, onAppTap = {})
    }
}

@Preview(name = "Apps light", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun AppsScreenLightPreview() {
    MetroTheme(darkTheme = false) {
        AppsScreen(entries = PreviewEntries, iconFor = { null }, onAppTap = {})
    }
}
