package com.example.hypermetro.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class MetroColors(
    val background: Color,
    val onBackground: Color,
    val onBackgroundSecondary: Color,
    /** Menü ve panel gibi arka planın üstünde duran yüzeyler. */
    val surface: Color,
    val accent: Color,
    val isDark: Boolean,
)

private val DarkBackground = Color(0xFF0B0F14)
private val LightBackground = Color(0xFFF2F4F7)

/**
 * [overWallpaper] true ise zemin yarı saydam bir karartmadır: pencerenin arkasındaki
 * sistem duvar kağıdı görünür ama yazılar okunur kalır.
 */
fun darkMetroColors(accent: Color, overWallpaper: Boolean = false) = MetroColors(
    background = if (overWallpaper) Color.Black.copy(alpha = 0.45f) else DarkBackground,
    onBackground = Color.White,
    onBackgroundSecondary = Color.White.copy(alpha = 0.7f),
    surface = Color(0xFF171E26),
    accent = accent,
    isDark = true,
)

fun lightMetroColors(accent: Color, overWallpaper: Boolean = false) = MetroColors(
    background = if (overWallpaper) Color.White.copy(alpha = 0.45f) else LightBackground,
    onBackground = DarkBackground,
    onBackgroundSecondary = DarkBackground.copy(alpha = 0.7f),
    surface = Color.White,
    accent = accent,
    isDark = false,
)

val LocalMetroColors = staticCompositionLocalOf { darkMetroColors(MetroAccent.Cobalt.color) }

/** Karo dolgusunun opaklığı (0.2..1). Duvar kağıdı görününce karolar saydamlaşabilir. */
val LocalTileOpacity = staticCompositionLocalOf { 1f }
