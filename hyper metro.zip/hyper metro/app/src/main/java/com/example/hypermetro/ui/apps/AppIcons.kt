package com.example.hypermetro.ui.apps

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import com.example.hypermetro.data.apps.AppInfo
import com.example.hypermetro.data.apps.AppRepository

/** İkonu arka planda yükler. Önbellekte varsa ilk karede hazır gelir. */
@Composable
fun rememberAppIcon(repository: AppRepository, app: AppInfo): ImageBitmap? {
    val state = produceState(initialValue = repository.cachedIcon(app), app.key) {
        if (value == null) value = repository.loadIcon(app)
    }
    return state.value
}

/** İkon yoksa aynı boyutta boşluk bırakır, yerleşim zıplamaz. */
@Composable
fun AppIcon(
    icon: ImageBitmap?,
    size: Dp,
    modifier: Modifier = Modifier,
    fillBounds: Boolean = false,
    appLabel: String? = null,
    hyperMetroStyle: Boolean = false,
) {
    if (hyperMetroStyle && appLabel != null &&
        HyperMetroIconOrNull(appLabel, size, modifier, tileBackground = fillBounds)
    ) return
    if (icon != null) {
        Image(
            bitmap = icon,
            contentDescription = null,
            modifier = if (fillBounds) modifier.fillMaxSize() else modifier.size(size),
            contentScale = ContentScale.Fit,
        )
    } else {
        Spacer(modifier.size(size))
    }
}
