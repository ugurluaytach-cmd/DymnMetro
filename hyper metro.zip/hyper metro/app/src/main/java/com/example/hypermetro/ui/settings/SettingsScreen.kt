package com.example.hypermetro.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import com.example.hypermetro.data.settings.BackgroundMode
import com.example.hypermetro.data.settings.LauncherSettings
import com.example.hypermetro.data.settings.ThemeMode
import com.example.hypermetro.data.settings.WallpaperPreset
import com.example.hypermetro.ui.components.DoneButton
import com.example.hypermetro.ui.components.PillButton
import com.example.hypermetro.ui.theme.MetroAccent
import com.example.hypermetro.ui.theme.MetroTheme
import com.example.hypermetro.ui.theme.MetroWallpaper
import com.example.hypermetro.ui.theme.CustomWallpaper
import com.example.hypermetro.ui.theme.AccentPalette
import com.example.hypermetro.ui.theme.onAccentFor

data class TileColorOption(
    val pageId: String,
    val key: String,
    val label: String,
    val color: Color?,
)

/**
 * Görünüm ayarları: tema, arka plan, accent rengi, karo saydamlığı.
 * Her değişiklik anında uygulanır ve kaydedilir. Metinler şimdilik sabit İngilizce.
 */
@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    onChange: (LauncherSettings) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    onAddClockTile: () -> Unit = {},
    onAddCalendarTile: () -> Unit = {},
    onSetDefaultLauncher: () -> Unit = {},
    onChooseWallpaper: () -> Unit = {},
    tileColorOptions: List<TileColorOption> = emptyList(),
    onTileColorChange: (pageId: String, key: String, color: Color?) -> Unit = { _, _, _ -> },
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    var showingTileColors by remember { mutableStateOf(false) }

    if (showingTileColors) {
        TileColorSettings(
            tiles = tileColorOptions,
            onColorChange = onTileColorChange,
            onClose = { showingTileColors = false },
        )
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            // Duvar kağıdı modunda colors.background saydam olur. Ayarlar tam opak olmalı.
            .background(colors.surface)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        BasicText(
            text = "settings",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp),
            style = typography.pageTitle.copy(color = colors.onBackground),
        )

        SectionTitle("theme")
        ChoiceRow(
            options = ThemeMode.entries,
            selected = settings.theme,
            label = { it.name.lowercase() },
            onSelect = { onChange(settings.copy(theme = it)) },
        )

        SectionTitle("background")
        ChoiceRow(
            options = BackgroundMode.entries,
            selected = settings.background,
            label = { it.name.lowercase() },
            onSelect = { onChange(settings.copy(background = it)) },
        )
        if (settings.background == BackgroundMode.Wallpaper) {
            SectionTitle("wallpaper style")
            WallpaperChoices(
                selected = settings.wallpaperPreset.takeUnless { settings.customWallpaperUri != null },
                onSelect = { onChange(settings.copy(wallpaperPreset = it, customWallpaperUri = null)) },
            )
            PillButton(
                text = if (settings.customWallpaperUri == null) "choose a photo" else "change photo",
                onClick = onChooseWallpaper,
                modifier = Modifier.padding(horizontal = 12.dp),
                width = 200.dp,
            )
            if (settings.savedWallpapers.isNotEmpty()) {
                SectionTitle("saved photos")
                SavedWallpaperChoices(
                    wallpapers = settings.savedWallpapers,
                    selected = settings.customWallpaperUri,
                    onSelect = { uri ->
                        onChange(
                            settings.copy(
                                background = BackgroundMode.Wallpaper,
                                customWallpaperUri = uri,
                            ),
                        )
                    },
                    onRemove = { uri ->
                        val removingActive = settings.customWallpaperUri == uri
                        onChange(
                            settings.copy(
                                savedWallpapers = settings.savedWallpapers.filterNot { it == uri },
                                customWallpaperUri = if (removingActive) null else settings.customWallpaperUri,
                                wallpaperPreset = if (removingActive) WallpaperPreset.System else settings.wallpaperPreset,
                            ),
                        )
                    },
                )
            }
        }

        SectionTitle("color palette")
        BasicText(
            text = "9 color families · 10 shades each · 90 choices",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
            style = typography.caption.copy(color = colors.onBackgroundSecondary),
        )
        AccentPicker(
            selectedId = AccentPalette.selectedId(settings.accentName),
            onSelect = { onChange(settings.copy(accentName = it)) },
        )
        PillButton(
            text = "customize tile colors",
            onClick = { showingTileColors = true },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            width = 240.dp,
        )

        SectionTitle("tiles per row")
        ChoiceRow(
            options = listOf(4, 5, 6, 8),
            selected = settings.tileColumns.coerceIn(4, 8),
            label = { it.toString() },
            onSelect = { onChange(settings.copy(tileColumns = it)) },
        )

        SectionTitle("icon style")
        ChoiceRow(
            options = listOf(false, true),
            selected = settings.hyperMetroIcons,
            label = { if (it) "HyperMetro" else "system" },
            onSelect = { onChange(settings.copy(hyperMetroIcons = it)) },
        )

        SectionTitle("tile transparency")
        PercentSlider(
            value = 100 - settings.tileOpacityPercent,
            onValueChange = { onChange(settings.copy(tileOpacityPercent = 100 - it)) },
        )

        SectionTitle("home screen")
        PillButton(
            text = "set as default launcher",
            onClick = onSetDefaultLauncher,
            modifier = Modifier.padding(horizontal = 12.dp),
            width = 240.dp,
        )

        SectionTitle("live tiles")
        PillButton(
            text = "add clock tile",
            onClick = onAddClockTile,
            modifier = Modifier.padding(horizontal = 12.dp),
            width = 200.dp,
        )
        PillButton(
            text = "add calendar tile",
            onClick = onAddCalendarTile,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            width = 200.dp,
        )

        Spacer(Modifier.height(24.dp))
        DoneButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.End)
                .padding(end = 12.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun TileColorSettings(
    tiles: List<TileColorOption>,
    onColorChange: (String, String, Color?) -> Unit,
    onClose: () -> Unit,
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    var selectedTile by remember { mutableStateOf<TileColorOption?>(null) }
    var activeFamilyId by remember { mutableStateOf("blue") }
    var selectedToneId by remember { mutableStateOf("blue_500") }

    Column(
        modifier = Modifier.fillMaxSize().background(colors.surface).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
    ) {
        BasicText(
            text = "tile colors",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp),
            style = typography.pageTitle.copy(color = colors.onBackground),
        )
        BasicText(
            text = "Select one tile. Changes apply only to that tile.",
            modifier = Modifier.padding(horizontal = 12.dp),
            style = typography.caption.copy(color = colors.onBackgroundSecondary),
        )
        if (tiles.isEmpty()) {
            BasicText(
                text = "Pin an app to a home page first.",
                modifier = Modifier.padding(16.dp),
                style = typography.body.copy(color = colors.onBackground),
            )
        }
        tiles.forEach { tile ->
            val isSelected = selectedTile?.pageId == tile.pageId && selectedTile?.key == tile.key
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isSelected) colors.accent.copy(alpha = .18f) else colors.background.copy(alpha = .45f))
                    .border(
                        if (isSelected) 2.dp else 1.dp,
                        if (isSelected) colors.accent else colors.onBackground.copy(alpha = .14f),
                        RoundedCornerShape(14.dp),
                    )
                    .clickable(role = Role.RadioButton) {
                        selectedTile = tile
                        val matchingTone = tile.color?.let { color ->
                            AccentPalette.tones.firstOrNull { it.color == color }
                        }
                        if (matchingTone != null) {
                            activeFamilyId = matchingTone.family.id
                            selectedToneId = matchingTone.id
                        }
                    }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier.size(34.dp).clip(RoundedCornerShape(9.dp))
                        .background(tile.color ?: colors.accent),
                )
                BasicText(tile.label, Modifier.weight(1f), style = typography.body.copy(color = colors.onBackground), maxLines = 1)
                BasicText(
                    if (tile.color == null) "default" else "custom",
                    style = typography.caption.copy(color = colors.onBackgroundSecondary),
                )
            }
        }

        val target = selectedTile
        if (target != null) {
            SectionTitle("color for ${target.label}")
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AccentPalette.families.forEach { family ->
                    val familyColor = AccentPalette.tones.first { it.id == "${family.id}_500" }.color
                    Box(
                        Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(familyColor)
                            .then(if (activeFamilyId == family.id) Modifier.border(2.dp, colors.onBackground, RoundedCornerShape(10.dp)) else Modifier)
                            .clickable { activeFamilyId = family.id },
                        contentAlignment = Alignment.Center,
                    ) {
                        BasicText(family.label.take(1), style = typography.caption.copy(color = onAccentFor(familyColor)))
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                AccentPalette.tones.filter { it.family.id == activeFamilyId }.forEach { tone ->
                    Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(tone.color)
                            .then(if (selectedToneId == tone.id) Modifier.border(2.dp, colors.onBackground, RoundedCornerShape(12.dp)) else Modifier)
                            .clickable {
                                selectedToneId = tone.id
                                onColorChange(target.pageId, target.key, tone.color)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        BasicText(tone.shade.toString(), style = typography.caption.copy(color = onAccentFor(tone.color)))
                    }
                }
            }
            PillButton(
                text = "use default color",
                onClick = { onColorChange(target.pageId, target.key, null) },
                modifier = Modifier.padding(horizontal = 12.dp),
                width = 200.dp,
            )
        }
        Spacer(Modifier.height(20.dp))
        DoneButton(onClick = onClose, modifier = Modifier.align(Alignment.End).padding(end = 12.dp))
    }
}

@Composable
private fun PercentSlider(value: Int, onValueChange: (Int) -> Unit) {
    val currentOnChange = rememberUpdatedState(onValueChange)
    val colors = MetroTheme.colors
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        BasicText(
            text = "${value.coerceIn(0, 100)}% transparent",
            style = MetroTheme.typography.caption.copy(color = colors.onBackgroundSecondary),
        )
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(38.dp)
                .semantics {
                    contentDescription = "Tile transparency"
                    progressBarRangeInfo = ProgressBarRangeInfo(value.coerceIn(0, 100) / 100f, 0f..1f)
                    setProgress { fraction ->
                        currentOnChange.value((fraction.coerceIn(0f, 1f) * 100).roundToInt())
                        true
                    }
                }
                .pointerInput(Unit) {
                    fun update(x: Float) {
                        currentOnChange.value((x / size.width.coerceAtLeast(1) * 100).roundToInt().coerceIn(0, 100))
                    }
                    detectTapGestures { update(it.x) }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        currentOnChange.value((change.position.x / size.width.coerceAtLeast(1) * 100).roundToInt().coerceIn(0, 100))
                        change.consume()
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val radius = 8.dp.toPx()
                val centerY = size.height / 2f
                val left = radius
                val right = size.width - radius
                val fraction = value.coerceIn(0, 100) / 100f
                val knobX = left + (right - left) * fraction
                drawLine(colors.onBackground.copy(alpha = .28f), Offset(left, centerY), Offset(right, centerY), 4.dp.toPx())
                drawLine(colors.accent, Offset(left, centerY), Offset(knobX, centerY), 4.dp.toPx())
                drawCircle(colors.accent, radius, Offset(knobX, centerY))
                drawCircle(Color.White, radius * .45f, Offset(knobX, centerY))
            }
        }
    }
}

@Composable
private fun SavedWallpaperChoices(
    wallpapers: List<String>,
    selected: String?,
    onSelect: (String) -> Unit,
    onRemove: (String) -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        wallpapers.forEach { uri ->
            Box(
                modifier = Modifier
                    .size(width = 120.dp, height = 104.dp)
                    .clip(shape)
                    .then(if (uri == selected) Modifier.border(3.dp, MetroTheme.colors.accent, shape) else Modifier)
                    .clickable(role = Role.RadioButton) { onSelect(uri) },
            ) {
                CustomWallpaper(uri, Modifier.matchParentSize())
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(32.dp)
                        .clip(RoundedCornerShape(bottomStart = 12.dp))
                        .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.58f))
                        .clickable(role = Role.Button) { onRemove(uri) },
                    contentAlignment = Alignment.Center,
                ) {
                    BasicText(
                        text = "×",
                        style = MetroTheme.typography.body.copy(color = androidx.compose.ui.graphics.Color.White),
                    )
                }
            }
        }
    }
}

@Composable
private fun WallpaperChoices(selected: WallpaperPreset?, onSelect: (WallpaperPreset) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (row in WallpaperPreset.entries.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (preset in row) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(96.dp)
                            .clip(shape)
                            .then(
                                if (preset == selected) Modifier.border(3.dp, MetroTheme.colors.accent, shape)
                                else Modifier
                            )
                            .clickable(role = Role.RadioButton) { onSelect(preset) },
                    ) {
                        MetroWallpaper(preset, Modifier.matchParentSize(), animate = false)
                        BasicText(
                            text = preset.name.lowercase(),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.48f))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MetroTheme.typography.caption.copy(color = androidx.compose.ui.graphics.Color.White),
                        )
                    }
                }
                repeat(2 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    BasicText(
        text = text,
        modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 20.dp, bottom = 8.dp),
        style = MetroTheme.typography.body.copy(
            color = MetroTheme.colors.onBackgroundSecondary,
            fontSize = 16.sp,
        ),
    )
}

/** Seçeneklerden birini seçtiren yan yana çipler. Seçili olan accent renkle dolu. */
@Composable
private fun <T> ChoiceRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
) {
    val colors = MetroTheme.colors
    val shape = RoundedCornerShape(22.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (option in options) {
            val isSelected = option == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(shape)
                    .then(
                        if (isSelected) {
                            Modifier.background(colors.accent)
                        } else {
                            Modifier.border(1.dp, colors.onBackground.copy(alpha = 0.4f), shape)
                        },
                    )
                    .clickable(role = Role.RadioButton) { onSelect(option) },
                contentAlignment = Alignment.Center,
            ) {
                BasicText(
                    text = label(option),
                    style = MetroTheme.typography.body.copy(
                        color = if (isSelected) onAccentFor(colors.accent) else colors.onBackground,
                    ),
                    maxLines = 1,
                )
            }
        }
    }
}

/** Selectable families, with a horizontal strip of 10 numbered shades for the active family. */
@Composable
private fun AccentPicker(selectedId: String, onSelect: (String) -> Unit) {
    val colors = MetroTheme.colors
    val selectedTone = AccentPalette.tones.first { it.id == selectedId }
    var activeFamilyId by remember(selectedId) { mutableStateOf(selectedTone.family.id) }
    val activeFamily = AccentPalette.families.first { it.id == activeFamilyId }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (rowItems in AccentPalette.families.chunked(4)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (family in rowItems) {
                    val swatch = AccentPalette.tones.first { it.id == "${family.id}_500" }
                    val isSelected = family.id == activeFamilyId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(swatch.color)
                            .then(
                                if (isSelected) {
                                    Modifier.border(3.dp, colors.onBackground, RoundedCornerShape(12.dp))
                                } else {
                                    Modifier
                                },
                            )
                            .clickable(role = Role.RadioButton) { activeFamilyId = family.id }
                            .semantics { contentDescription = family.label },
                        contentAlignment = Alignment.Center,
                    ) {
                        BasicText(
                            text = family.label,
                            style = MetroTheme.typography.caption.copy(
                                color = onAccentFor(swatch.color),
                                fontSize = 11.sp,
                            ),
                            maxLines = 1,
                        )
                    }
                }
                // Son sıra eksik kalırsa kareler aynı genişlikte kalsın.
                repeat(4 - rowItems.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AccentPalette.tones.filter { it.family.id == activeFamily.id }.forEach { tone ->
                val isSelected = tone.id == selectedId
                Column(
                    modifier = Modifier
                        .size(width = 48.dp, height = 60.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(tone.color)
                        .then(if (isSelected) Modifier.border(3.dp, colors.onBackground, RoundedCornerShape(10.dp)) else Modifier)
                        .clickable(role = Role.RadioButton) { onSelect(tone.id) }
                        .semantics { contentDescription = tone.label },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    BasicText(
                        text = tone.shade.toString(),
                        style = MetroTheme.typography.caption.copy(color = onAccentFor(tone.color), fontSize = 11.sp),
                    )
                }
            }
        }
    }
}

@Preview(name = "Settings dark", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun SettingsScreenDarkPreview() {
    MetroTheme(darkTheme = true) {
        SettingsScreen(settings = LauncherSettings(), onChange = {}, onClose = {})
    }
}

@Preview(name = "Settings light", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun SettingsScreenLightPreview() {
    MetroTheme(darkTheme = false) {
        SettingsScreen(settings = LauncherSettings(), onChange = {}, onClose = {})
    }
}
