package com.example.hypermetro

import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.content.Intent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.setValue
import com.example.hypermetro.data.settings.BackgroundMode
import com.example.hypermetro.data.settings.SettingsStore
import com.example.hypermetro.data.settings.ThemeMode
import com.example.hypermetro.data.settings.WallpaperPreset
import com.example.hypermetro.ui.LauncherRoot
import com.example.hypermetro.ui.theme.MetroTheme
import com.example.hypermetro.ui.theme.AccentPalette
import com.example.hypermetro.ui.theme.CustomWallpaper
import com.example.hypermetro.ui.theme.MetroWallpaper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val store = remember { SettingsStore(applicationContext) }
            var settings by remember { mutableStateOf(store.load()) }
            val showSystemWallpaper = settings.background == BackgroundMode.Wallpaper &&
                settings.customWallpaperUri == null && settings.wallpaperPreset == WallpaperPreset.System

            SideEffect {
                window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                if (showSystemWallpaper) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
                }
            }

            val systemDark = isSystemInDarkTheme()
            val dark = when (settings.theme) {
                ThemeMode.System -> systemDark
                ThemeMode.Dark -> true
                ThemeMode.Light -> false
            }

            MetroTheme(
                darkTheme = dark,
                accent = AccentPalette.color(settings.accentName),
                overWallpaper = settings.background == BackgroundMode.Wallpaper,
                tileOpacity = settings.tileOpacityPercent / 100f,
            ) {
                Box(Modifier.fillMaxSize()) {
                    if (settings.background == BackgroundMode.Wallpaper &&
                        settings.customWallpaperUri != null
                    ) {
                        CustomWallpaper(settings.customWallpaperUri!!, Modifier.fillMaxSize())
                    } else if (settings.background == BackgroundMode.Wallpaper &&
                        settings.wallpaperPreset != WallpaperPreset.System
                    ) {
                        MetroWallpaper(settings.wallpaperPreset, Modifier.fillMaxSize())
                    }
                    LauncherRoot(
                        settings = settings,
                        onSettingsChange = { updated ->
                            val removedWallpapers = settings.savedWallpapers.toSet() - updated.savedWallpapers.toSet()
                            removedWallpapers.forEach { oldUri ->
                                runCatching {
                                    contentResolver.releasePersistableUriPermission(
                                        Uri.parse(oldUri),
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                                    )
                                }
                            }
                            settings = updated
                            store.save(updated)
                        },
                    )
                }
            }
        }
    }
}
