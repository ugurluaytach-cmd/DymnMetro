package com.example.hypermetro.data.apps

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.UserHandle
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.text.Collator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Yüklü uygulamaları LauncherApps servisiyle okur. Bu servis launcher'lar için
 * tasarlandı: iş profilini bilir, ikonları sistemin istediği şekilde (adaptive, badge) verir.
 */
class AppRepository(context: Context) {
    private val appContext = context.applicationContext
    private val launcherApps = appContext.getSystemService(LauncherApps::class.java)
    private val iconCache = LruCache<String, ImageBitmap>(ICON_CACHE_SIZE)

    /** Uygulamaları ada göre (cihazın dil kurallarıyla) sıralı verir. Kendimizi listeden çıkarırız. */
    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.Default) {
        val collator = Collator.getInstance()
        launcherApps.profiles
            .flatMap { user -> launcherApps.getActivityList(null, user) }
            .filter { it.componentName.packageName != appContext.packageName }
            .map { AppInfo(it) }
            .sortedWith(Comparator { a, b -> collator.compare(a.label, b.label) })
    }

    fun launch(app: AppInfo) {
        try {
            launcherApps.startMainActivity(app.componentName, app.user, null, null)
        } catch (e: Exception) {
            // Uygulama o sırada kaldırılmış ya da kilitlenmiş olabilir. Şimdilik sessiz geç.
        }
    }

    /** Sistemin "uygulama bilgisi" ekranını açar. */
    fun openAppInfo(app: AppInfo) {
        try {
            launcherApps.startAppDetailsActivity(app.componentName, app.user, null, null)
        } catch (e: Exception) {
            // Uygulama o sırada kaldırılmış olabilir.
        }
    }

    /**
     * Sistem silme onayını açar. Android 9+ için manifestte REQUEST_DELETE_PACKAGES gerekir.
     * Sistem uygulamaları silinemez, sistem kendi mesajını gösterir.
     */
    fun uninstall(app: AppInfo) {
        try {
            val intent = Intent(
                Intent.ACTION_DELETE,
                Uri.parse("package:${app.componentName.packageName}"),
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
        } catch (e: Exception) {
            // Silme ekranı açılamazsa sessiz geç.
        }
    }

    fun cachedIcon(app: AppInfo): ImageBitmap? = iconCache.get(app.key)

    suspend fun loadIcon(app: AppInfo): ImageBitmap? = withContext(Dispatchers.Default) {
        iconCache.get(app.key) ?: try {
            app.info.getBadgedIcon(0)
                .toBitmap(ICON_PX, ICON_PX)
                .asImageBitmap()
                .also { iconCache.put(app.key, it) }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Uygulama eklenince/kaldırılınca/güncellenince [onChange] çağrılır.
     * Dönen fonksiyon dinlemeyi bırakır (DisposableEffect içinde çağır).
     */
    fun registerChangeListener(onChange: () -> Unit): () -> Unit {
        val callback = object : LauncherApps.Callback() {
            private fun changed() {
                iconCache.evictAll()
                onChange()
            }

            override fun onPackageRemoved(packageName: String?, user: UserHandle?) = changed()
            override fun onPackageAdded(packageName: String?, user: UserHandle?) = changed()
            override fun onPackageChanged(packageName: String?, user: UserHandle?) = changed()
            override fun onPackagesAvailable(
                packageNames: Array<out String>?,
                user: UserHandle?,
                replacing: Boolean,
            ) = changed()

            override fun onPackagesUnavailable(
                packageNames: Array<out String>?,
                user: UserHandle?,
                replacing: Boolean,
            ) = changed()
        }
        launcherApps.registerCallback(callback)
        return { launcherApps.unregisterCallback(callback) }
    }

    private companion object {
        const val ICON_PX = 128
        const val ICON_CACHE_SIZE = 256
    }
}
