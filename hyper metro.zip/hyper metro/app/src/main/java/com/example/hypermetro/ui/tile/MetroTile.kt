package com.example.hypermetro.ui.tile

import android.provider.Settings
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hypermetro.ui.theme.LocalTileOpacity

/** Karo ayarları. Sayılar taslak, denerken ayarlanır (bkz. docs/DESIGN-LANGUAGE.md). */
object MetroTileDefaults {
    val CornerSmall: Dp = 16.dp
    val CornerLarge: Dp = 22.dp
    val BorderWidth: Dp = 1.dp
    val BorderColor: Color = Color.White.copy(alpha = 0.12f)

    /** Gradient'in alt ucundaki koyulaşma oranı. Fark edilmeyecek kadar az olmalı. */
    const val GradientDarken: Float = 0.08f

    const val PressedScale: Float = 0.97f

    /** Düzenleme modunda karolar hafif küçülür (Metro'daki "tile edit" hissi). */
    const val EditScale: Float = 0.94f
    const val MaxTiltDegrees: Float = 6f

    const val SpringDamping: Float = 0.8f
    const val SpringStiffness: Float = 400f
}

/**
 * Tek bir Metro/HyperOS karosu.
 *
 * - Düz accent dolgu + çok hafif alt gradient + 1dp iç çizgi
 * - Basınca dokunulan noktaya doğru yatar ve küçülür (spring)
 * - "Hareketi azalt" (animasyon ölçeği 0) açıksa tilt ve küçülme kapanır
 *
 * Not: Köşe şimdilik RoundedCornerShape. Sürekli köşe (squircle) Adım 15'te.
 */
@Composable
fun MetroTile(
    accent: Color,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = MetroTileDefaults.CornerLarge,
    description: String? = null,
    editing: Boolean = false,
    tapWhileEditing: Boolean = false,
    onTap: () -> Unit = {},
    onLongPress: () -> Unit = {},
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(cornerRadius)
    val reduceMotion = rememberReduceMotion()
    val haptics = LocalHapticFeedback.current
    val currentOnTap by rememberUpdatedState(onTap)
    val currentOnLongPress by rememberUpdatedState(onLongPress)

    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var pressed by remember { mutableStateOf(false) }
    // Dokunulan nokta, karo merkezine göre -1..1 aralığında.
    var touchX by remember { mutableFloatStateOf(0f) }
    var touchY by remember { mutableFloatStateOf(0f) }

    // Düzenleme modunda basma animasyonu kapalı. Uzun basıp moda girerken "pressed" takılı
    // kalabilir, bu yüzden burada da editing kontrol edilir.
    val motionOn = pressed && !reduceMotion && !editing
    val springSpec = spring<Float>(
        dampingRatio = MetroTileDefaults.SpringDamping,
        stiffness = MetroTileDefaults.SpringStiffness,
    )
    val scale by animateFloatAsState(
        targetValue = if (motionOn) MetroTileDefaults.PressedScale else 1f,
        animationSpec = springSpec,
        label = "tileScale",
    )
    val editSpec: AnimationSpec<Float> = if (reduceMotion) snap() else springSpec
    val editScale by animateFloatAsState(
        targetValue = if (editing) MetroTileDefaults.EditScale else 1f,
        animationSpec = editSpec,
        label = "tileEditScale",
    )
    // İşaretler denemede ters gelirse burada çevrilir.
    val tiltX by animateFloatAsState(
        targetValue = if (motionOn) touchY * MetroTileDefaults.MaxTiltDegrees else 0f,
        animationSpec = springSpec,
        label = "tileTiltX",
    )
    val tiltY by animateFloatAsState(
        targetValue = if (motionOn) -touchX * MetroTileDefaults.MaxTiltDegrees else 0f,
        animationSpec = springSpec,
        label = "tileTiltY",
    )

    val opacity = LocalTileOpacity.current
    val fill = Brush.verticalGradient(
        listOf(
            accent.copy(alpha = opacity),
            lerp(accent, Color.Black, MetroTileDefaults.GradientDarken).copy(alpha = opacity),
        ),
    )

    Box(
        modifier = modifier
            .onSizeChanged { boxSize = it }
            .graphicsLayer {
                scaleX = scale * editScale
                scaleY = scale * editScale
                rotationX = tiltX
                rotationY = tiltY
                cameraDistance = 12f * density
            }
            .clip(shape)
            .background(fill)
            .border(MetroTileDefaults.BorderWidth, MetroTileDefaults.BorderColor, shape)
            .semantics(mergeDescendants = true) {
                role = Role.Button
                if (description != null) this.contentDescription = description
                onClick { currentOnTap(); true }
                onLongClick { currentOnLongPress(); true }
            }
            .pointerInput(editing, tapWhileEditing) {
                // Mod değişince bu blok yeniden başlar. Takılı kalmış basılı durumu sıfırla.
                pressed = false
                // Düzenlemede dokunma ve sürükleme MetroGrid'e ait, karo kendi jestini bırakır.
                if (editing && !tapWhileEditing) return@pointerInput
                detectTapGestures(
                    onPress = { offset ->
                        val w = boxSize.width.coerceAtLeast(1)
                        val h = boxSize.height.coerceAtLeast(1)
                        touchX = ((offset.x / w) * 2f - 1f).coerceIn(-1f, 1f)
                        touchY = ((offset.y / h) * 2f - 1f).coerceIn(-1f, 1f)
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { currentOnTap() },
                    onLongPress = {
                        if (editing) return@detectTapGestures
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        currentOnLongPress()
                    },
                )
            },
        content = content,
    )
}

/** Sistem animasyon ölçeği 0 ise (hareketi azalt / animasyonları kapat) true döner. */
@Composable
fun rememberReduceMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        try {
            Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f,
            ) == 0f
        } catch (e: Exception) {
            false // Preview ya da okunamayan durumda hareket açık kalsın.
        }
    }
}

@Preview(name = "Tile", showBackground = true, backgroundColor = 0xFF0B0F14)
@Composable
private fun MetroTilePreview() {
    MetroTile(
        accent = Color(0xFF1E6FD9),
        modifier = Modifier
            .padding(16.dp)
            .size(width = 170.dp, height = 170.dp),
    ) {
        BasicText(
            text = "Phone",
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp),
            style = TextStyle(
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            ),
        )
    }
}
