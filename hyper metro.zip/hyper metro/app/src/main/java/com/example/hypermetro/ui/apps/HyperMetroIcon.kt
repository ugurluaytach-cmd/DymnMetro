package com.example.hypermetro.ui.apps

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.runtime.Composable
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private enum class Glyph(val color: Color) {
    Phone(Color(0xFF1676D2)), Message(Color(0xFF00A8A8)), Mail(Color(0xFF2768B2)),
    Calendar(Color(0xFFE45B52)), Camera(Color(0xFF703FB2)), Photos(Color(0xFF00A4C7)),
    Maps(Color(0xFF259667)), Browser(Color(0xFF168CB5)), Contacts(Color(0xFF6757B8)),
    Settings(Color(0xFF526579)), Files(Color(0xFFE0A52B)), Music(Color(0xFFCC4384)),
    Video(Color(0xFFD94A45)), Store(Color(0xFF1989C7)), Clock(Color(0xFF266CC1)),
    Notes(Color(0xFF7D5BA6)), Calculator(Color(0xFF368B73)), Weather(Color(0xFF4281BD)),
    Wallet(Color(0xFF438B68)), Shopping(Color(0xFFE2783C)), Books(Color(0xFF6655AB)),
    Health(Color(0xFFE45263)), Security(Color(0xFF238B83)), Downloads(Color(0xFF4679B8)),
    Home(Color(0xFFB36C45)), Assistant(Color(0xFF5269C8)), Games(Color(0xFF29956B)),
}

private fun glyphFor(label: String): Glyph? {
    val name = label.lowercase()
    return when {
        listOf("phone", "dialer", "telephone", "call").any(name::contains) -> Glyph.Phone
        listOf("message", "messaging", "sms", "chat", "whatsapp", "telegram").any(name::contains) -> Glyph.Message
        listOf("mail", "gmail", "outlook", "email").any(name::contains) -> Glyph.Mail
        listOf("calendar", "agenda").any(name::contains) -> Glyph.Calendar
        listOf("camera").any(name::contains) -> Glyph.Camera
        listOf("photo", "gallery", "images").any(name::contains) -> Glyph.Photos
        listOf("maps", "navigation", "here wego").any(name::contains) -> Glyph.Maps
        listOf("browser", "chrome", "firefox", "edge", "internet").any(name::contains) -> Glyph.Browser
        listOf("contact", "people", "address book").any(name::contains) -> Glyph.Contacts
        listOf("settings", "preferences").any(name::contains) -> Glyph.Settings
        listOf("files", "file manager", "drive", "onedrive").any(name::contains) -> Glyph.Files
        listOf("music", "spotify", "audio", "radio").any(name::contains) -> Glyph.Music
        listOf("youtube", "video", "movies", "tv").any(name::contains) -> Glyph.Video
        listOf("store", "play store", "market").any(name::contains) -> Glyph.Store
        listOf("clock", "alarm", "timer").any(name::contains) -> Glyph.Clock
        listOf("notes", "keep", "notepad").any(name::contains) -> Glyph.Notes
        listOf("calculator", "calc").any(name::contains) -> Glyph.Calculator
        listOf("weather", "forecast").any(name::contains) -> Glyph.Weather
        listOf("wallet", "bank", "pay", "finance").any(name::contains) -> Glyph.Wallet
        listOf("shopping", "amazon", "shop", "marketplace").any(name::contains) -> Glyph.Shopping
        listOf("book", "reading", "kindle", "library").any(name::contains) -> Glyph.Books
        listOf("health", "fitness", "fitbit", "workout", "sport").any(name::contains) -> Glyph.Health
        listOf("security", "antivirus", "vpn", "protection").any(name::contains) -> Glyph.Security
        listOf("download", "downloads").any(name::contains) -> Glyph.Downloads
        listOf("smart home", "home control", "home app").any(name::contains) -> Glyph.Home
        listOf("assistant", "ai ", "copilot").any(name::contains) -> Glyph.Assistant
        listOf("game", "gaming", "play games").any(name::contains) -> Glyph.Games
        else -> null
    }
}

fun hasHyperMetroGlyph(label: String): Boolean = glyphFor(label) != null

/** Original HyperMetro line glyphs. Unmapped apps continue to use their Android-provided icon. */
@Composable
fun HyperMetroIconOrNull(label: String, size: Dp, modifier: Modifier = Modifier, tileBackground: Boolean = false): Boolean {
    val glyph = glyphFor(label) ?: return false
    val shape = RoundedCornerShape(if (tileBackground) 10.dp else 13.dp)
    Box(
        modifier = modifier
            .then(if (tileBackground) Modifier.clip(shape) else Modifier.size(size))
            .then(if (tileBackground) Modifier.background(Color.Transparent) else Modifier.clip(shape).background(glyph.color))
            .semantics { contentDescription = label },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val unit = this.size.minDimension
            val scale = unit / 100f
            val left = (this.size.width - unit) / 2f
            val top = (this.size.height - unit) / 2f
            withTransform({ translate(left, top); scale(scale, scale, Offset.Zero) }) {
                val ink = if (tileBackground) Color.White else Color.White
                val stroke = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
                    drawLine(ink, Offset(x1, y1), Offset(x2, y2), stroke.width, StrokeCap.Round)
                fun path(vararg points: Float) {
                    val p = Path().apply {
                        moveTo(points[0], points[1])
                        for (i in 2 until points.size step 2) lineTo(points[i], points[i + 1])
                    }
                    drawPath(p, ink, style = stroke)
                }
                when (glyph) {
                    Glyph.Phone -> {
                        val p = Path().apply {
                            moveTo(32f, 19f); quadraticTo(25f, 20f, 24f, 29f)
                            quadraticTo(29f, 58f, 67f, 76f); quadraticTo(78f, 80f, 82f, 68f)
                            lineTo(67f, 59f); lineTo(57f, 68f); quadraticTo(42f, 60f, 35f, 44f)
                            lineTo(43f, 35f); close()
                        }
                        drawPath(p, ink)
                    }
                    Glyph.Message -> {
                        drawRoundRect(ink, Offset(19f, 22f), Size(62f, 48f), androidx.compose.ui.geometry.CornerRadius(10f), style = stroke)
                        path(32f, 70f, 25f, 82f, 45f, 70f); line(32f, 40f, 68f, 40f); line(32f, 53f, 58f, 53f)
                    }
                    Glyph.Mail -> {
                        drawRoundRect(ink, Offset(16f, 27f), Size(68f, 48f), androidx.compose.ui.geometry.CornerRadius(5f), style = stroke)
                        path(19f, 32f, 50f, 54f, 81f, 32f)
                    }
                    Glyph.Calendar -> {
                        drawRoundRect(ink, Offset(20f, 23f), Size(60f, 59f), androidx.compose.ui.geometry.CornerRadius(8f), style = stroke)
                        line(21f, 41f, 79f, 41f); line(36f, 16f, 36f, 32f); line(64f, 16f, 64f, 32f)
                        line(38f, 53f, 38f, 53f); line(60f, 53f, 60f, 53f); line(38f, 67f, 38f, 67f); line(60f, 67f, 60f, 67f)
                    }
                    Glyph.Camera -> {
                        drawRoundRect(ink, Offset(15f, 31f), Size(70f, 48f), androidx.compose.ui.geometry.CornerRadius(10f), style = stroke)
                        drawCircle(ink, 15f, Offset(50f, 55f), style = stroke); drawRoundRect(ink, Offset(31f, 22f), Size(22f, 10f), androidx.compose.ui.geometry.CornerRadius(4f))
                    }
                    Glyph.Photos -> {
                        drawCircle(ink, 8f, Offset(70f, 30f)); path(15f, 75f, 37f, 48f, 49f, 62f, 62f, 43f, 86f, 75f)
                    }
                    Glyph.Maps -> {
                        val p = Path().apply { moveTo(50f, 84f); cubicTo(43f, 72f, 27f, 53f, 27f, 40f); cubicTo(27f, 10f, 73f, 10f, 73f, 40f); cubicTo(73f, 53f, 57f, 72f, 50f, 84f); close() }
                        drawPath(p, ink, style = stroke); drawCircle(ink, 8f, Offset(50f, 40f), style = stroke)
                    }
                    Glyph.Browser -> {
                        drawCircle(ink, 34f, Offset(50f, 50f), style = stroke); line(17f, 50f, 83f, 50f)
                        val p = Path().apply { moveTo(50f, 16f); cubicTo(28f, 34f, 28f, 66f, 50f, 84f); moveTo(50f, 16f); cubicTo(72f, 34f, 72f, 66f, 50f, 84f) }
                        drawPath(p, ink, style = stroke)
                    }
                    Glyph.Contacts -> {
                        drawCircle(ink, 12f, Offset(50f, 32f)); drawArc(ink, 205f, 130f, false, Offset(20f, 45f), Size(60f, 49f), style = stroke)
                    }
                    Glyph.Settings -> {
                        drawCircle(ink, 22f, Offset(50f, 50f), style = stroke); drawCircle(ink, 8f, Offset(50f, 50f), style = stroke)
                        for (a in 0 until 8) { val rad = a * Math.PI / 4; line(50f + (27 * kotlin.math.cos(rad)).toFloat(), 50f + (27 * kotlin.math.sin(rad)).toFloat(), 50f + (38 * kotlin.math.cos(rad)).toFloat(), 50f + (38 * kotlin.math.sin(rad)).toFloat()) }
                    }
                    Glyph.Files -> path(18f, 34f, 43f, 34f, 50f, 43f, 82f, 43f, 78f, 76f, 18f, 76f, 18f, 34f)
                    Glyph.Music -> {
                        line(61f, 24f, 61f, 67f); line(61f, 25f, 81f, 20f); line(81f, 20f, 81f, 60f)
                        drawCircle(ink, 10f, Offset(50f, 70f)); drawCircle(ink, 10f, Offset(70f, 63f))
                    }
                    Glyph.Video -> {
                        drawRoundRect(ink, Offset(17f, 25f), Size(66f, 50f), androidx.compose.ui.geometry.CornerRadius(10f), style = stroke)
                        path(43f, 38f, 63f, 50f, 43f, 62f, 43f, 38f)
                    }
                    Glyph.Store -> {
                        drawRoundRect(ink, Offset(22f, 37f), Size(56f, 44f), androidx.compose.ui.geometry.CornerRadius(5f), style = stroke)
                        drawArc(ink, 180f, 180f, false, Offset(34f, 18f), Size(32f, 38f), style = stroke)
                    }
                    Glyph.Clock -> {
                        drawCircle(ink, 34f, Offset(50f, 50f), style = stroke); line(50f, 50f, 50f, 29f); line(50f, 50f, 68f, 59f)
                    }
                    Glyph.Notes -> {
                        drawRoundRect(ink, Offset(24f, 16f), Size(52f, 68f), androidx.compose.ui.geometry.CornerRadius(6f), style = stroke)
                        line(36f, 38f, 64f, 38f); line(36f, 51f, 64f, 51f); line(36f, 64f, 58f, 64f)
                    }
                    Glyph.Calculator -> {
                        drawRoundRect(ink, Offset(25f, 15f), Size(50f, 70f), androidx.compose.ui.geometry.CornerRadius(6f), style = stroke)
                        line(36f, 34f, 64f, 34f); line(38f, 49f, 38f, 49f); line(50f, 49f, 50f, 49f); line(62f, 49f, 62f, 49f); line(38f, 66f, 38f, 66f); line(50f, 66f, 50f, 66f); line(62f, 66f, 62f, 66f)
                    }
                    Glyph.Weather -> {
                        drawCircle(ink, 17f, Offset(42f, 49f)); drawCircle(ink, 21f, Offset(61f, 45f)); drawRoundRect(ink, Offset(24f, 48f), Size(54f, 24f), androidx.compose.ui.geometry.CornerRadius(12f))
                    }
                    Glyph.Wallet -> {
                        drawRoundRect(ink, Offset(17f, 27f), Size(66f, 48f), androidx.compose.ui.geometry.CornerRadius(8f), style = stroke)
                        drawRoundRect(ink, Offset(56f, 42f), Size(30f, 19f), androidx.compose.ui.geometry.CornerRadius(6f), style = stroke); drawCircle(ink, 2.5f, Offset(67f, 51.5f))
                    }
                    Glyph.Shopping -> {
                        path(18f, 27f, 82f, 27f, 73f, 67f, 29f, 67f, 18f, 27f)
                        line(14f, 18f, 22f, 27f); drawCircle(ink, 4f, Offset(36f, 79f)); drawCircle(ink, 4f, Offset(68f, 79f))
                    }
                    Glyph.Books -> {
                        drawRoundRect(ink, Offset(18f, 22f), Size(24f, 57f), androidx.compose.ui.geometry.CornerRadius(4f), style = stroke)
                        drawRoundRect(ink, Offset(47f, 17f), Size(34f, 62f), androidx.compose.ui.geometry.CornerRadius(4f), style = stroke)
                        line(54f, 34f, 74f, 34f); line(54f, 47f, 70f, 47f)
                    }
                    Glyph.Health -> {
                        val heart = Path().apply { moveTo(50f, 78f); cubicTo(40f, 68f, 19f, 53f, 19f, 38f); cubicTo(19f, 18f, 43f, 17f, 50f, 35f); cubicTo(58f, 17f, 81f, 18f, 81f, 38f); cubicTo(81f, 53f, 60f, 68f, 50f, 78f) }
                        drawPath(heart, ink, style = stroke); path(20f, 50f, 37f, 50f, 44f, 39f, 54f, 62f, 62f, 49f, 80f, 49f)
                    }
                    Glyph.Security -> {
                        val shield = Path().apply { moveTo(50f, 15f); lineTo(80f, 27f); lineTo(76f, 57f); cubicTo(70f, 72f, 60f, 81f, 50f, 86f); cubicTo(40f, 81f, 30f, 72f, 24f, 57f); lineTo(20f, 27f); close() }
                        drawPath(shield, ink, style = stroke); path(36f, 50f, 46f, 60f, 65f, 40f)
                    }
                    Glyph.Downloads -> {
                        line(50f, 15f, 50f, 60f); path(32f, 45f, 50f, 63f, 68f, 45f)
                        drawRoundRect(ink, Offset(22f, 67f), Size(56f, 16f), androidx.compose.ui.geometry.CornerRadius(6f), style = stroke)
                    }
                    Glyph.Home -> {
                        path(14f, 47f, 50f, 17f, 86f, 47f, 78f, 47f, 78f, 82f, 56f, 82f, 56f, 60f, 43f, 60f, 43f, 82f, 22f, 82f, 22f, 47f, 14f, 47f)
                    }
                    Glyph.Assistant -> {
                        path(50f, 14f, 55f, 39f, 78f, 50f, 55f, 56f, 50f, 84f, 44f, 56f, 21f, 50f, 44f, 39f, 50f, 14f)
                        drawCircle(ink, 4f, Offset(77f, 23f)); drawCircle(ink, 3f, Offset(24f, 77f))
                    }
                    Glyph.Games -> {
                        val pad = Path().apply { moveTo(29f, 35f); lineTo(71f, 35f); cubicTo(80f, 35f, 85f, 49f, 88f, 66f); cubicTo(90f, 79f, 81f, 82f, 73f, 70f); lineTo(27f, 70f); cubicTo(19f, 82f, 10f, 79f, 12f, 66f); cubicTo(15f, 49f, 20f, 35f, 29f, 35f); close() }
                        drawPath(pad, ink, style = stroke); line(30f, 47f, 30f, 63f); line(22f, 55f, 38f, 55f); drawCircle(ink, 3f, Offset(66f, 51f)); drawCircle(ink, 3f, Offset(76f, 60f))
                    }
                }
            }
        }
    }
    return true
}
