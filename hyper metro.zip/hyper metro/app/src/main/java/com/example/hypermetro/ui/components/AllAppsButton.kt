package com.example.hypermetro.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.hypermetro.ui.theme.MetroTheme

/** Start ekranının altındaki "tüm uygulamalar" oku. Yuvarlak, ince çizgili, içinde sağ ok. */
@Composable
fun AllAppsButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val color = MetroTheme.colors.onBackground

    Box(
        modifier = modifier
            .size(48.dp)
            .clip(CircleShape)
            .border(2.dp, color, CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = "All apps" },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(20.dp)) {
            val stroke = 2.dp.toPx()
            val w = size.width
            val h = size.height
            // Gövde: soldan sağa düz çizgi
            drawLine(color, Offset(0f, h / 2), Offset(w, h / 2), stroke, StrokeCap.Round)
            // Uç: iki kısa çizgi
            drawLine(color, Offset(w * 0.55f, h * 0.15f), Offset(w, h / 2), stroke, StrokeCap.Round)
            drawLine(color, Offset(w * 0.55f, h * 0.85f), Offset(w, h / 2), stroke, StrokeCap.Round)
        }
    }
}
