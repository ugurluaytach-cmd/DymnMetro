package com.example.hypermetro.ui.grid

import com.example.hypermetro.data.layout.StoredTile

/** Kayıtlı boyut adını TileSize'a çevirir. Bilinmeyen ad küçük karo sayılır. */
fun tileSizeOf(name: String): TileSize =
    TileSize.entries.firstOrNull { it.name == name } ?: TileSize.Small

/*
 * Start düzeni üzerindeki işlemler. Hepsi saf fonksiyon: yeni liste döner, eskisine dokunmaz.
 * Böylece arayüzden bağımsız düşünülür ve ileride kolayca test edilir.
 */

/** [key] karosunu bir sonraki boyuta geçirir. */
fun List<StoredTile>.withNextSize(key: String): List<StoredTile> = map { tile ->
    if (tile.key == key) tile.copy(size = tileSizeOf(tile.size).nextResize().name) else tile
}

/** [key] karosunu Start'tan kaldırır (uygulama silinmez). */
fun List<StoredTile>.without(key: String): List<StoredTile> = filterNot { it.key == key }

/** [key] zaten Start'ta değilse sona ekler. */
fun List<StoredTile>.pinned(key: String, size: TileSize = TileSize.Small): List<StoredTile> =
    if (any { it.key == key }) this else this + StoredTile(key, size.name)

/** [fromKey] karosunu [toKey] karosunun yerine alır, aradakiler kayar. */
fun List<StoredTile>.moved(fromKey: String, toKey: String): List<StoredTile> {
    val from = indexOfFirst { it.key == fromKey }
    val to = indexOfFirst { it.key == toKey }
    if (from < 0 || to < 0 || from == to) return this
    val result = toMutableList()
    val tile = result.removeAt(from)
    result.add(to, tile)
    return result
}

/** Moves [key] to an absolute insertion index in the remaining tile order. */
fun List<StoredTile>.movedToIndex(key: String, targetIndex: Int): List<StoredTile> {
    val from = indexOfFirst { it.key == key }
    if (from < 0) return this
    val result = toMutableList()
    val tile = result.removeAt(from)
    result.add(targetIndex.coerceIn(0, result.size), tile)
    return result
}

/** Saves a free grid cell for a tile so auto-packing cannot move it back. */
fun List<StoredTile>.atPosition(key: String, col: Int, row: Int): List<StoredTile> = map { tile ->
    if (tile.key == key) tile.copy(col = col, row = row) else tile
}
