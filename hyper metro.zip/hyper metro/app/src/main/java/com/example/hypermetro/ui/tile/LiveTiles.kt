package com.example.hypermetro.ui.tile

import android.text.format.DateFormat
import android.Manifest
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.example.hypermetro.ui.grid.TileSize
import com.example.hypermetro.ui.theme.MetroTheme
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

/**
 * Uygulamaya bağlı olmayan, launcher'ın kendi çizdiği "canlı" karoların kimlikleri.
 * Kimlik "live:" ile başlar, böylece uygulama anahtarlarıyla karışmaz.
 */
const val ClockTileId = "live:clock"
const val CalendarTileId = "live:calendar"

data class AgendaPreview(val title: String, val startMillis: Long)

/** Reads just the next event, and only after the user has granted calendar access. */
fun nextAgendaEvent(context: android.content.Context): AgendaPreview? {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) !=
        PackageManager.PERMISSION_GRANTED
    ) return null
    val now = System.currentTimeMillis()
    return try {
        context.contentResolver.query(
            CalendarContract.Instances.CONTENT_URI.buildUpon()
                .appendPath(now.toString())
                .appendPath((now + 30L * 24 * 60 * 60 * 1000).toString())
                .build(),
            arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
            null,
            null,
            "${CalendarContract.Instances.BEGIN} ASC",
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                AgendaPreview(cursor.getString(0).orEmpty(), cursor.getLong(1))
            } else null
        }
    } catch (_: SecurityException) {
        null
    }
}

/**
 * Saat ve tarih karosunun içeriği. Dakika başında kendini yeniler (pil dostu: saniye yok).
 * Boyuta göre uyarlanır: küçükte sadece saat, orta ve geniş karoda saat + tarih.
 */
@Composable
fun ClockTileContent(
    size: TileSize,
    textColor: Color,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val typography = MetroTheme.typography
    val is24Hour = remember(context) { DateFormat.is24HourFormat(context) }
    val timeFormatter = remember(is24Hour) {
        DateTimeFormatter.ofPattern(if (is24Hour) "HH:mm" else "h:mm")
    }
    val dateFormatter = remember {
        DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())
    }

    // Bir sonraki dakika başına kadar bekler, sonra saati günceller.
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }

    val timeSize = when (size) {
        TileSize.Small -> 20.sp
        TileSize.Medium -> 36.sp
        TileSize.Wide, TileSize.Large -> 56.sp
    }

    Column(modifier = modifier.padding(12.dp)) {
        BasicText(
            text = now.format(timeFormatter),
            style = typography.display.copy(
                color = textColor,
                fontSize = timeSize,
                lineHeight = timeSize * 1.1f,
            ),
            maxLines = 1,
            softWrap = false,
        )
        if (size != TileSize.Small) {
            BasicText(
                text = now.format(dateFormatter),
                style = typography.body.copy(color = textColor.copy(alpha = 0.85f)),
                maxLines = 1,
            )
        }
    }
}

/** Small, provider-free calendar preview. The next agenda item is supplied by the caller. */
@Composable
fun CalendarTileContent(
    size: TileSize,
    textColor: Color,
    eventTitle: String?,
    eventTime: String?,
    modifier: Modifier = Modifier,
) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val dateLabel = remember(now.toLocalDate()) {
        now.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()))
    }
    val titleSize = if (size == TileSize.Small) 14.sp else 22.sp
    Column(modifier = modifier.padding(12.dp)) {
        BasicText(
            text = now.dayOfMonth.toString(),
            style = MetroTheme.typography.display.copy(
                color = textColor,
                fontSize = if (size == TileSize.Small) 30.sp else 48.sp,
                lineHeight = if (size == TileSize.Small) 34.sp else 52.sp,
            ),
            maxLines = 1,
        )
        BasicText(
            text = dateLabel,
            style = MetroTheme.typography.body.copy(color = textColor.copy(alpha = 0.85f)),
            maxLines = 1,
        )
        if (size != TileSize.Small) {
            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
            BasicText(
                text = eventTitle ?: "No upcoming events",
                style = MetroTheme.typography.body.copy(
                    color = textColor,
                    fontSize = titleSize,
                    fontWeight = FontWeight.Medium,
                ),
                maxLines = if (size == TileSize.Large) 2 else 1,
            )
            if (eventTime != null) {
                BasicText(
                    text = eventTime,
                    style = MetroTheme.typography.body.copy(color = textColor.copy(alpha = 0.8f)),
                    maxLines = 1,
                )
            }
        }
    }
}
