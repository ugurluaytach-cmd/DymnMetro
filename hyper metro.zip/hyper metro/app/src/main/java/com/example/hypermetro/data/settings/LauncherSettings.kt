package com.example.hypermetro.data.settings

import android.content.Context
import org.json.JSONArray

/** Start ve Apps'in arkasında ne görünsün. */
enum class BackgroundMode {
    /** Düz koyu/açık zemin. */
    Solid,

    /** Sistem duvar kağıdı, okunurluk için hafif karartma ile. */
    Wallpaper,
}

enum class ThemeMode { System, Dark, Light }

enum class WallpaperPreset { System, Aurora, Sunset, Ocean, Forest, Graphite, Rose, Flow, Orbit }

/**
 * Kullanıcının seçtiği görünüm ayarları.
 * [accentName] MetroAccent adı (ui katmanına bağımlı kalmamak için metin tutulur).
 * [tileOpacityPercent] karo dolgusunun opaklığı, 20..100.
 */
data class LauncherSettings(
    val background: BackgroundMode = BackgroundMode.Solid,
    val theme: ThemeMode = ThemeMode.System,
    val accentName: String = "Cobalt",
    val tileColumns: Int = 4,
    val hyperMetroIcons: Boolean = true,
    val tileOpacityPercent: Int = 100,
    val wallpaperPreset: WallpaperPreset = WallpaperPreset.System,
    val customWallpaperUri: String? = null,
    val savedWallpapers: List<String> = emptyList(),
)

/** Ayarları SharedPreferences'ta saklar. Bozuk ya da bilinmeyen değerler varsayılana düşer. */
class SettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun load(): LauncherSettings {
        val defaults = LauncherSettings()
        val customWallpaperUri = prefs.getString(KEY_CUSTOM_WALLPAPER_URI, null)
        val savedWallpapers = runCatching {
            val json = prefs.getString(KEY_SAVED_WALLPAPERS, null) ?: "[]"
            JSONArray(json).let { array ->
                List(array.length()) { index -> array.optString(index) }.filter(String::isNotBlank)
            }
        }.getOrDefault(emptyList())
        return LauncherSettings(
            background = parse(prefs.getString(KEY_BACKGROUND, null), defaults.background),
            theme = parse(prefs.getString(KEY_THEME, null), defaults.theme),
            accentName = prefs.getString(KEY_ACCENT, null) ?: defaults.accentName,
            tileColumns = prefs.getInt(KEY_TILE_COLUMNS, defaults.tileColumns).coerceIn(4, 8),
            hyperMetroIcons = prefs.getBoolean(KEY_HYPERMETRO_ICONS, defaults.hyperMetroIcons),
            tileOpacityPercent = prefs
                .getInt(KEY_TILE_OPACITY, defaults.tileOpacityPercent)
                .coerceIn(MIN_OPACITY, 100),
            wallpaperPreset = parse(prefs.getString(KEY_WALLPAPER_PRESET, null), defaults.wallpaperPreset),
            customWallpaperUri = customWallpaperUri,
            // Migrate custom wallpapers saved by earlier builds into the personal gallery.
            savedWallpapers = (savedWallpapers + listOfNotNull(customWallpaperUri)).distinct(),
        )
    }

    fun save(settings: LauncherSettings) {
        prefs.edit()
            .putString(KEY_BACKGROUND, settings.background.name)
            .putString(KEY_THEME, settings.theme.name)
            .putString(KEY_ACCENT, settings.accentName)
            .putInt(KEY_TILE_COLUMNS, settings.tileColumns.coerceIn(4, 8))
            .putBoolean(KEY_HYPERMETRO_ICONS, settings.hyperMetroIcons)
            .putInt(KEY_TILE_OPACITY, settings.tileOpacityPercent.coerceIn(MIN_OPACITY, 100))
            .putString(KEY_WALLPAPER_PRESET, settings.wallpaperPreset.name)
            .putString(KEY_CUSTOM_WALLPAPER_URI, settings.customWallpaperUri)
            .putString(KEY_SAVED_WALLPAPERS, JSONArray(settings.savedWallpapers.distinct()).toString())
            .apply()
    }

    private inline fun <reified E : Enum<E>> parse(name: String?, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default

    private companion object {
        const val PREFS_NAME = "launcher_settings"
        const val KEY_BACKGROUND = "background"
        const val KEY_THEME = "theme"
        const val KEY_ACCENT = "accent"
        const val KEY_TILE_COLUMNS = "tile_columns"
        const val KEY_HYPERMETRO_ICONS = "hypermetro_icons"
        const val KEY_TILE_OPACITY = "tile_opacity"
        const val KEY_WALLPAPER_PRESET = "wallpaper_preset"
        const val KEY_CUSTOM_WALLPAPER_URI = "custom_wallpaper_uri"
        const val KEY_SAVED_WALLPAPERS = "saved_wallpapers"
        const val MIN_OPACITY = 0
    }
}
