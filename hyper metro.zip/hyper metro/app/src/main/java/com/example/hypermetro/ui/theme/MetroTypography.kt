package com.example.hypermetro.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Yazı tipi tek yerden değişir. Inter / Manrope / Outfit kararı verilince
 * font dosyaları res/font'a konur ve buradaki satır güncellenir.
 */
object MetroFonts {
    val family: FontFamily = FontFamily.Default
}

@Immutable
class MetroTypography(
    /** Büyük saat ve sayılar. Light. */
    val display: TextStyle,
    /** Sayfa başlığı ("apps", "start"). Light, küçük harfle yazılır. */
    val pageTitle: TextStyle,
    /** Karo etiketi. Medium. */
    val tileTitle: TextStyle,
    val body: TextStyle,
    val caption: TextStyle,
)

fun defaultMetroTypography(): MetroTypography = MetroTypography(
    display = TextStyle(
        fontFamily = MetroFonts.family,
        fontWeight = FontWeight.Light,
        fontSize = 56.sp,
        lineHeight = 60.sp,
    ),
    pageTitle = TextStyle(
        fontFamily = MetroFonts.family,
        fontWeight = FontWeight.Light,
        fontSize = 40.sp,
        lineHeight = 44.sp,
    ),
    tileTitle = TextStyle(
        fontFamily = MetroFonts.family,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 18.sp,
    ),
    body = TextStyle(
        fontFamily = MetroFonts.family,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
    caption = TextStyle(
        fontFamily = MetroFonts.family,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
    ),
)

val LocalMetroTypography = staticCompositionLocalOf { defaultMetroTypography() }
