package com.example.hypermetro.ui.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hypermetro.ui.theme.MetroTheme

/**
 * Uygulama listesinde uzun basınca altta açılan menü.
 * Metinler şimdilik sabit İngilizce, dil desteği ayarlar adımında strings.xml'e taşınacak.
 */
@Composable
fun AppActionsMenu(
    title: String,
    pinned: Boolean,
    onPinToggle: () -> Unit,
    onMoveToPage: (() -> Unit)? = null,
    onAppInfo: () -> Unit,
    onUninstall: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    // Ripple istemiyoruz: dışarı dokunmak sadece kapatsın, panele dokunmak bir şey yapmasın.
    val scrimInteraction = remember { MutableInteractionSource() }
    val panelInteraction = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable(
                interactionSource = scrimInteraction,
                indication = null,
                onClick = onDismiss,
            ),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.surface)
                .clickable(
                    interactionSource = panelInteraction,
                    indication = null,
                    onClick = {},
                )
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
        ) {
            BasicText(
                text = title,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                style = typography.pageTitle.copy(
                    color = colors.onBackground,
                    fontSize = 24.sp,
                ),
                maxLines = 1,
            )
            MenuItem(if (pinned) "unpin from start" else "pin to start", onPinToggle)
            if (pinned && onMoveToPage != null) {
                MenuItem("move to page", onMoveToPage)
            }
            MenuItem("app info", onAppInfo)
            MenuItem("uninstall", onUninstall)
        }
    }
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicText(
            text = text,
            style = typography.body.copy(color = colors.onBackground, fontSize = 18.sp),
        )
    }
}

@Preview(name = "Menu", showBackground = true, widthDp = 360, heightDp = 480)
@Composable
private fun AppActionsMenuPreview() {
    MetroTheme(darkTheme = true) {
        AppActionsMenu(
            title = "Camera",
            pinned = false,
            onPinToggle = {},
            onAppInfo = {},
            onUninstall = {},
            onDismiss = {},
        )
    }
}
