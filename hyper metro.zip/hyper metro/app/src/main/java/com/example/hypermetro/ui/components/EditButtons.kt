package com.example.hypermetro.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.hypermetro.ui.theme.MetroTheme

enum class EditGlyph { Close, Resize }

private val GlyphColor = Color(0xFF0B0F14)

/**
 * Düzenleme modunda karonun köşesindeki yuvarlak buton.
 * Görünen daire 26dp. Dokunma alanı 40dp: küçük karoda (yaklaşık 80dp) iki buton üst üste
 * binmesin diye 48dp'nin biraz altında tutuldu.
 */
@Composable
fun TileEditButton(
    glyph: EditGlyph,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(40.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.size(12.dp)) {
                val stroke = 2.dp.toPx()
                val w = size.width
                val h = size.height
                when (glyph) {
                    EditGlyph.Close -> {
                        drawLine(GlyphColor, Offset(0f, 0f), Offset(w, h), stroke, StrokeCap.Round)
                        drawLine(GlyphColor, Offset(w, 0f), Offset(0f, h), stroke, StrokeCap.Round)
                    }
                    EditGlyph.Resize -> {
                        // Sağ alt köşeye doğru çapraz ok
                        drawLine(GlyphColor, Offset(0f, 0f), Offset(w, h), stroke, StrokeCap.Round)
                        drawLine(GlyphColor, Offset(w, h * 0.35f), Offset(w, h), stroke, StrokeCap.Round)
                        drawLine(GlyphColor, Offset(w * 0.35f, h), Offset(w, h), stroke, StrokeCap.Round)
                    }
                }
            }
        }
    }
}

/** Yuvarlak köşeli, ince çizgili, metinli buton. "customize" gibi ikincil eylemler için. */
@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 128.dp,
    selected: Boolean = false,
) {
    val color = if (selected) MetroTheme.colors.accent else MetroTheme.colors.onBackground
    val shape = RoundedCornerShape(24.dp)

    Box(
        modifier = modifier
            .size(width = width, height = 48.dp)
            .clip(shape)
            .background(if (selected) color else Color.Transparent)
            .border(2.dp, color, shape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        BasicText(
            text = text,
            style = MetroTheme.typography.body.copy(
                color = if (selected) com.example.hypermetro.ui.theme.onAccentFor(color) else color,
            ),
        )
    }
}

/** Düzenleme modundan çıkış: Start'ın altında, ok butonunun yerinde durur. */
@Composable
fun DoneButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val color = MetroTheme.colors.onBackground
    val shape = RoundedCornerShape(24.dp)

    Box(
        modifier = modifier
            .size(width = 96.dp, height = 48.dp)
            .clip(shape)
            .border(2.dp, color, shape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        BasicText(
            text = "done",
            style = MetroTheme.typography.body.copy(color = color),
        )
    }
}
