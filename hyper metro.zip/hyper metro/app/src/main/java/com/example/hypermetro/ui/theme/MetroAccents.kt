package com.example.hypermetro.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import kotlin.math.max
import kotlin.math.min

/** Seçilebilir accent renkleri. Hex değerleri taslak, gözle denerken ayarlanır. */
enum class MetroAccent(val label: String, val color: Color) {
    Cobalt("Kobalt", Color(0xFF1E6FD9)),
    Azure("Açık Mavi", Color(0xFF2196F3)),
    Teal("Turkuaz", Color(0xFF0E8C8C)),
    Emerald("Zümrüt", Color(0xFF1E9A57)),
    Lime("Misket", Color(0xFF7BA318)),
    Amber("Kehribar", Color(0xFFE0A100)),
    Orange("Turuncu", Color(0xFFE56A12)),
    Red("Kırmızı", Color(0xFFD6322F)),
    Pink("Pembe", Color(0xFFD22F86)),
    Violet("Mor", Color(0xFF7A3FD0)),

    // Hidden legacy values keep old settings readable while the visible palette stays focused.
    Crimson("Vişne", Color(0xFFB5174A)),
    Indigo("Çivit", Color(0xFF4A4FCB)),
    Steel("Çelik", Color(0xFF5B7083));

    companion object {
        /** Ten quick-pick swatches: a compact spread of cool, green, warm, and vivid tones. */
        val palette = listOf(Cobalt, Azure, Teal, Emerald, Lime, Amber, Orange, Red, Pink, Violet)
    }
}

/** Kayıtlı accent adını bulur. Bilinmiyorsa Kobalt. */
fun accentOf(name: String): MetroAccent =
    when (name) {
        "Crimson" -> MetroAccent.Red
        "Indigo" -> MetroAccent.Violet
        "Steel" -> MetroAccent.Cobalt
        else -> MetroAccent.entries.firstOrNull { it.name == name } ?: MetroAccent.Cobalt
    }

private val NearBlack = Color(0xFF0B0F14)

/** WCAG kontrast oranı (1..21). */
fun contrastRatio(a: Color, b: Color): Float {
    val la = a.luminance()
    val lb = b.luminance()
    val lighter = max(la, lb)
    val darker = min(la, lb)
    return (lighter + 0.05f) / (darker + 0.05f)
}

/** Accent üstünde okunacak metin rengi: beyaz ya da koyu, hangisinin kontrastı yüksekse. */
fun onAccentFor(accent: Color): Color =
    if (contrastRatio(Color.White, accent) >= contrastRatio(NearBlack, accent)) Color.White else NearBlack
