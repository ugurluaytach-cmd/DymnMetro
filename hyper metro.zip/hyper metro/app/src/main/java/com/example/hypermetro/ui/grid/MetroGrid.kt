package com.example.hypermetro.ui.grid

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.snap
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt
import com.example.hypermetro.ui.components.EditGlyph
import com.example.hypermetro.ui.components.TileEditButton
import com.example.hypermetro.ui.tile.MetroTile
import com.example.hypermetro.ui.tile.MetroTileDefaults
import com.example.hypermetro.ui.tile.rememberReduceMotion

/**
 * Sabit sütunlu karo ızgarası. Karolar [tiles] içindeki konumlarına çizilir.
 * Kaydırma dışarıdan verilir (ör. verticalScroll), bu yüzden yükseklik içeriğe göredir.
 *
 * Düzenleme modunda ([editing]):
 * - karoya uzun basıp sürüklemek karoyu taşır, başka karonun üstüne bırakınca yer değiştirir
 * - sağ üstteki buton Start'tan kaldırır, sağ alttaki boyutu değiştirir
 * - normal dokunma uygulamayı açmaz
 * Sürüklemede kenara yaklaşınca otomatik kaydırma henüz yok (sonraki iyileştirme).
 */
@Composable
fun MetroGrid(
    tiles: List<PlacedTile>,
    defaultAccent: Color,
    modifier: Modifier = Modifier,
    columns: Int = 4,
    gap: Dp = 6.dp,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp),
    editing: Boolean = false,
    createFolderMode: Boolean = false,
    colorMode: Boolean = false,
    onTileTap: (TileItem) -> Unit = {},
    onTileLongPress: (TileItem) -> Unit = {},
    onUnpin: (TileItem) -> Unit = {},
    onResize: (TileItem) -> Unit = {},
    onTileDrop: (fromId: String, targetId: String?, col: Int, row: Int, fromCol: Int, fromRow: Int) -> Unit = { _, _, _, _, _, _ -> },
    tileContent: @Composable BoxScope.(PlacedTile) -> Unit,
) {
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current
    val reduceMotion = rememberReduceMotion()
    // Sürükleme blokları uzun yaşar, bu yüzden güncel değerleri bu şekilde okuruz.
    val currentTiles by rememberUpdatedState(tiles)
    val currentOnTileDrop by rememberUpdatedState(onTileDrop)

    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var dropAnchor by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .padding(contentPadding),
    ) {
        val unit = (maxWidth - gap * (columns - 1)) / columns
        val unitPx = with(density) { unit.toPx() }
        val gapPx = with(density) { gap.toPx() }
        val cellPx = unitPx + gapPx
        val rowCount = tiles.maxOfOrNull { it.row + it.item.size.rows } ?: 0
        val displayRows = rowCount + if (editing) 2 else 0
        val totalHeight = unit * displayRows + gap * (displayRows - 1).coerceAtLeast(0)

        /** Karonun ızgara içindeki dikdörtgeni (piksel). Bırakma noktasını bulmak için. */
        fun rectOf(p: PlacedTile): Rect {
            val w = unitPx * p.item.size.cols + gapPx * (p.item.size.cols - 1)
            val h = unitPx * p.item.size.rows + gapPx * (p.item.size.rows - 1)
            return Rect(p.col * cellPx, p.row * cellPx, p.col * cellPx + w, p.row * cellPx + h)
        }

        fun finishDrag(id: String) {
            val mine = currentTiles.firstOrNull { it.item.id == id }
            if (mine != null) {
                val center = rectOf(mine).center + dragOffset
                val remaining = currentTiles.filterNot { it.item.id == id }
                val target = remaining.firstOrNull {
                    !it.item.id.startsWith("live:") && rectOf(it).contains(center)
                }
                if (target != null) {
                    currentOnTileDrop(id, target.item.id, target.col, target.row, mine.col, mine.row)
                } else {
                    // First resolve the grid cell under the released tile, then fall back
                    // to the closest free anchor if the requested footprint is occupied.
                    // Using the tile's top-left keeps edge drops into adjacent empty cells
                    // predictable (especially for small tiles at the end of a row).
                    val maxRow = (remaining.maxOfOrNull { it.row + it.item.size.rows } ?: 0) +
                        mine.item.size.rows + 8
                    val tileWidth = unitPx * mine.item.size.cols + gapPx * (mine.item.size.cols - 1)
                    val tileHeight = unitPx * mine.item.size.rows + gapPx * (mine.item.size.rows - 1)
                    val requestedCol = ((center.x - tileWidth / 2f) / cellPx).roundToInt()
                        .coerceIn(0, columns - mine.item.size.cols)
                    val requestedRow = ((center.y - tileHeight / 2f) / cellPx)
                        .roundToInt().coerceIn(0, maxRow)
                    val requested = PlacedTile(mine.item, requestedCol, requestedRow)
                    val requestedFits = remaining.none { rectOf(it).overlaps(rectOf(requested)) }
                    var best: Pair<Int, Int>? = if (requestedFits) requestedCol to requestedRow else null
                    var bestDistance = Float.POSITIVE_INFINITY
                    if (!requestedFits) {
                        for (row in 0..maxRow) {
                            for (col in 0..(columns - mine.item.size.cols)) {
                                val candidate = PlacedTile(mine.item, col, row)
                                val candidateRect = rectOf(candidate)
                                if (remaining.any { rectOf(it).overlaps(candidateRect) }) continue
                                val dx = candidateRect.center.x - center.x
                                val dy = candidateRect.center.y - center.y
                                val distance = dx * dx + dy * dy
                                if (distance < bestDistance) {
                                    best = col to row
                                    bestDistance = distance
                                }
                            }
                        }
                    }
                    best?.let { (col, row) -> currentOnTileDrop(id, null, col, row, mine.col, mine.row) }
                }
            }
            draggingId = null
            dragOffset = Offset.Zero
            dropAnchor = null
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(totalHeight),
        ) {
            if (editing) {
                Canvas(Modifier.fillMaxSize()) {
                    val unitSize = unit.toPx()
                    val gapSize = gap.toPx()
                    val pitch = unitSize + gapSize
                    val anchor = dropAnchor
                    for (row in 0 until displayRows) {
                        for (col in 0 until columns) {
                            val isDropTarget = anchor != null && draggingId != null &&
                                col in anchor.first until anchor.first +
                                    (currentTiles.firstOrNull { it.item.id == draggingId }?.item?.size?.cols ?: 1) &&
                                row in anchor.second until anchor.second +
                                    (currentTiles.firstOrNull { it.item.id == draggingId }?.item?.size?.rows ?: 1)
                            val inset = 2.dp.toPx()
                            val cell = androidx.compose.ui.geometry.Offset(col * pitch + inset, row * pitch + inset)
                            val rectSize = androidx.compose.ui.geometry.Size(unitSize - inset * 2, unitSize - inset * 2)
                            if (isDropTarget) {
                                drawRoundRect(
                                    color = defaultAccent.copy(alpha = if (createFolderMode) 0.26f else 0.20f),
                                    topLeft = cell,
                                    size = rectSize,
                                    cornerRadius = CornerRadius(10.dp.toPx()),
                                )
                            }
                            drawRoundRect(
                                color = defaultAccent.copy(alpha = if (isDropTarget) 0.95f else 0.28f),
                                topLeft = cell,
                                size = rectSize,
                                cornerRadius = CornerRadius(10.dp.toPx()),
                                style = Stroke(width = if (isDropTarget) 2.dp.toPx() else 1.dp.toPx()),
                            )
                        }
                    }
                }
            }
            for (placed in tiles) {
                // key: sıra değişince karonun durumu (sürükleme jesti dahil) karışmasın.
                key(placed.item.id) {
                    val item = placed.item
                    val id = item.id
                    val size = item.size
                    val width = unit * size.cols + gap * (size.cols - 1)
                    val height = unit * size.rows + gap * (size.rows - 1)
                    val isDragging = draggingId == id
                    val tileX by animateDpAsState(
                        targetValue = (unit + gap) * placed.col,
                        animationSpec = if (reduceMotion) snap() else spring(
                            dampingRatio = 0.85f,
                            stiffness = 380f,
                        ),
                        label = "tileX_$id",
                    )
                    val tileY by animateDpAsState(
                        targetValue = (unit + gap) * placed.row,
                        animationSpec = if (reduceMotion) snap() else spring(
                            dampingRatio = 0.85f,
                            stiffness = 380f,
                        ),
                        label = "tileY_$id",
                    )

                    Box(
                        modifier = Modifier
                            .offset(x = tileX, y = tileY)
                            .size(width, height)
                            .zIndex(if (isDragging) 1f else 0f)
                            // Jest, görsel kaymadan ÖNCE gelmeli. Aksi halde karo parmakla
                            // birlikte kayarken sürükleme miktarı sıfıra yakın görünür.
            .pointerInput(editing, colorMode, id) {
                                if (editing && !colorMode) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = {
                                            draggingId = id
                                            dragOffset = Offset.Zero
                                            dropAnchor = placed.col to placed.row
                                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragOffset += amount
                                            val center = rectOf(placed).center + dragOffset
                                            val tileWidth = unitPx * size.cols + gapPx * (size.cols - 1)
                                            val tileHeight = unitPx * size.rows + gapPx * (size.rows - 1)
                                            val maxRow = (displayRows - size.rows).coerceAtLeast(0)
                                            dropAnchor =
                                                (((center.x - tileWidth / 2f) / cellPx).roundToInt()
                                                    .coerceIn(0, columns - size.cols)) to
                                                (((center.y - tileHeight / 2f) / cellPx).roundToInt()
                                                    .coerceIn(0, maxRow))
                                        },
                                        onDragEnd = { finishDrag(id) },
                                        onDragCancel = {
                                            draggingId = null
                                            dragOffset = Offset.Zero
                                            dropAnchor = null
                                        },
                                    )
                                }
                            }
                            .graphicsLayer {
                                if (isDragging) {
                                    translationX = dragOffset.x
                                    translationY = dragOffset.y
                                }
                            },
                    ) {
                        MetroTile(
                            accent = item.accent ?: defaultAccent,
                            modifier = Modifier.fillMaxSize(),
                            cornerRadius = cornerFor(size),
                            description = item.label,
                            editing = editing,
                            tapWhileEditing = colorMode,
                            onTap = { if (!editing || colorMode) onTileTap(item) },
                            onLongPress = { if (!editing) onTileLongPress(item) },
                        ) {
                            // İç içe iki BoxScope var, bu yüzden alıcı açıkça verilir.
                            this.tileContent(placed)
                        }

                        if (editing) {
                            TileEditButton(
                                glyph = EditGlyph.Close,
                                description = "Unpin ${item.label}",
                                onClick = { onUnpin(item) },
                                modifier = Modifier.align(Alignment.TopEnd),
                            )
                            TileEditButton(
                                glyph = EditGlyph.Resize,
                                description = "Resize ${item.label}",
                                onClick = { onResize(item) },
                                modifier = Modifier.align(Alignment.BottomEnd),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Küçük karolar biraz daha az yuvarlak, geri kalanı büyük köşe. */
private fun cornerFor(size: TileSize): Dp =
    if (size == TileSize.Small) MetroTileDefaults.CornerSmall else MetroTileDefaults.CornerLarge
