package com.example.hypermetro.ui

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hypermetro.ui.apps.AppIcon
import com.example.hypermetro.ui.components.AllAppsButton
import com.example.hypermetro.ui.components.DoneButton
import com.example.hypermetro.ui.components.PillButton
import com.example.hypermetro.ui.grid.MetroGrid
import com.example.hypermetro.ui.grid.EditTool
import com.example.hypermetro.ui.grid.TileItem
import com.example.hypermetro.ui.grid.TileSize
import com.example.hypermetro.ui.grid.packTiles
import com.example.hypermetro.ui.tile.ClockTileContent
import com.example.hypermetro.ui.tile.ClockTileId
import com.example.hypermetro.ui.tile.CalendarTileId
import com.example.hypermetro.ui.tile.CalendarTileContent
import com.example.hypermetro.ui.tile.nextAgendaEvent
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.example.hypermetro.ui.theme.MetroAccent
import com.example.hypermetro.ui.theme.MetroTheme
import com.example.hypermetro.ui.theme.AccentPalette
import com.example.hypermetro.ui.theme.onAccentFor

/**
 * Start ekranı.
 *
 * @param items gösterilecek karolar (varsayılan: örnek karolar, Preview için)
 * @param tileIcon karo için ikon; null dönerse sadece etiket çizilir
 * @param editing düzenleme modu açık mı (sürükle, boyutlandır, kaldır)
 * @param onTileTap karoya dokunulunca
 * @param onTileLongPress karoya uzun basılınca (düzenleme moduna geçiş için)
 * @param onUnpin düzenlemede karoyu Start'tan kaldır
 * @param onResize düzenlemede karonun boyutunu değiştir
 * @param onTileDrop bırakılan karo, hedef karo ve boş hücre koordinatlarını bildirir
 * @param onOpenApps alttaki oka dokunulunca (tüm uygulamalar listesi)
 * @param onDoneEditing düzenleme modunda "done" butonuna dokunulunca
 * @param onCustomize düzenleme modunda "customize" (ayarlar) butonuna dokunulunca
 * @param scrollState dışarıdan verilirse sayfa geçişlerinde kaydırma konumu korunur
 */
@Composable
fun StartScreen(
    items: List<TileItem> = SampleTiles,
    columns: Int = 4,
    hyperMetroIcons: Boolean = true,
    tileIcon: @Composable (TileItem) -> ImageBitmap? = { null },
    editing: Boolean = false,
    editTool: EditTool = EditTool.Move,
    pageIndex: Int = 0,
    pageCount: Int = 1,
    onTileTap: (TileItem) -> Unit = {},
    onTileLongPress: (TileItem) -> Unit = {},
    onUnpin: (TileItem) -> Unit = {},
    onResize: (TileItem) -> Unit = {},
    onTileDrop: (fromId: String, targetId: String?, col: Int, row: Int, fromCol: Int, fromRow: Int) -> Unit = { _, _, _, _, _, _ -> },
    onTileColorChange: (String, Color?) -> Unit = { _, _ -> },
    onEditToolChange: (EditTool) -> Unit = {},
    onSelectPage: (String) -> Unit = {},
    onAddPage: () -> Unit = {},
    pageIds: List<String> = emptyList(),
    onOpenApps: () -> Unit = {},
    onDoneEditing: () -> Unit = {},
    onCustomize: () -> Unit = {},
    scrollState: ScrollState = rememberScrollState(),
    calendarRefresh: Int = 0,
) {
    val colors = MetroTheme.colors
    val typography = MetroTheme.typography
    val tiles = remember(items, columns) { packTiles(items, columns) }
    var activeFamilyId by remember { mutableStateOf("blue") }
    var selectedToneId by remember { mutableStateOf("blue_500") }
    var clearTileColor by remember { mutableStateOf(false) }
    val activeFamily = AccentPalette.families.first { it.id == activeFamilyId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .systemBarsPadding()
            .verticalScroll(scrollState),
    ) {
        MetroGrid(
            tiles = tiles,
            defaultAccent = colors.accent,
            columns = columns,
            editing = editing,
            createFolderMode = editTool == EditTool.CreateFolder,
            colorMode = editTool == EditTool.Color,
            onTileTap = { item ->
                if (editTool == EditTool.Color) {
                    val color = if (clearTileColor) null else AccentPalette.tones.first { it.id == selectedToneId }.color
                    onTileColorChange(item.id, color)
                } else onTileTap(item)
            },
            onTileLongPress = onTileLongPress,
            onUnpin = onUnpin,
            onResize = onResize,
            onTileDrop = onTileDrop,
        ) { placed ->
            val accent = placed.item.accent ?: colors.accent
            val icon = tileIcon(placed.item)
            if (placed.item.folderMembers.isNotEmpty()) {
                val wide = placed.item.size == TileSize.Wide
                val previewSize = when (placed.item.size) {
                    TileSize.Small -> 0.dp
                    TileSize.Medium -> 84.dp
                    TileSize.Wide -> 128.dp
                    TileSize.Large -> 176.dp
                }
                FolderTilePreview(
                    members = placed.item.folderMembers,
                    tileIcon = tileIcon,
                    hyperMetroIcons = hyperMetroIcons,
                    modifier = if (placed.item.size == TileSize.Small) {
                        Modifier.fillMaxSize().padding(5.dp)
                    } else {
                        Modifier
                            .align(if (wide) Alignment.CenterStart else Alignment.TopStart)
                            .padding(start = tileInsetFor(placed.item.size), top = if (wide) 0.dp else tileInsetFor(placed.item.size))
                            .size(previewSize)
                    },
                )
                if (placed.item.size != TileSize.Small) {
                    BasicText(
                        text = placed.item.label,
                        modifier = Modifier
                            .align(if (wide) Alignment.CenterEnd else Alignment.BottomStart)
                            .padding(
                                start = if (wide) previewSize + tileInsetFor(placed.item.size) + 8.dp else tileInsetFor(placed.item.size),
                                end = if (wide) tileInsetFor(placed.item.size) else 0.dp,
                                bottom = if (wide) 0.dp else tileInsetFor(placed.item.size),
                            ),
                        style = typography.tileTitle.copy(color = onAccentFor(accent), fontSize = tileLabelSizeFor(placed.item.size)),
                        maxLines = 1,
                    )
                }
            } else if (placed.item.id == ClockTileId) {
                ClockTileContent(
                    size = placed.item.size,
                    textColor = onAccentFor(accent),
                    modifier = Modifier.align(Alignment.BottomStart),
                )
            } else if (placed.item.id == CalendarTileId) {
                val context = androidx.compose.ui.platform.LocalContext.current
                val event = remember(placed.item.id, calendarRefresh) { nextAgendaEvent(context) }
                CalendarTileContent(
                    size = placed.item.size,
                    textColor = onAccentFor(accent),
                    eventTitle = event?.title?.takeIf { it.isNotBlank() },
                    eventTime = event?.startMillis?.let {
                        DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault())
                            .format(Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()))
                    },
                    modifier = Modifier.align(Alignment.BottomStart),
                )
            } else {
                val hasIcon = icon != null || (hyperMetroIcons && com.example.hypermetro.ui.apps.hasHyperMetroGlyph(placed.item.label))
                if (hasIcon && placed.item.size == TileSize.Small) {
                    // Small tiles keep the classic icon-only treatment.
                    AppIcon(
                        icon = icon,
                        size = iconSizeFor(placed.item.size),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(5.dp),
                        fillBounds = true,
                        appLabel = placed.item.label,
                        hyperMetroStyle = hyperMetroIcons,
                    )
                } else if (hasIcon) {
                    val wide = placed.item.size == TileSize.Wide
                    val inset = tileInsetFor(placed.item.size)
                    AppIcon(
                        icon = icon,
                        size = iconSizeFor(placed.item.size),
                        modifier = Modifier
                            .align(if (wide) Alignment.CenterStart else Alignment.TopStart)
                            .padding(start = inset, top = if (wide) 0.dp else inset),
                        appLabel = placed.item.label,
                        hyperMetroStyle = hyperMetroIcons,
                    )
                }
                if (placed.item.size != TileSize.Small || !hasIcon) {
                    val wide = placed.item.size == TileSize.Wide && hasIcon
                    BasicText(
                        text = placed.item.label,
                        modifier = Modifier
                            .align(if (wide) Alignment.CenterEnd else Alignment.BottomStart)
                            .padding(
                                start = if (wide) iconSizeFor(placed.item.size) + tileInsetFor(placed.item.size) + 8.dp
                                else tileInsetFor(placed.item.size),
                                end = if (wide) tileInsetFor(placed.item.size) else 0.dp,
                                bottom = if (wide) 0.dp else tileInsetFor(placed.item.size),
                            ),
                        style = typography.tileTitle.copy(
                            color = onAccentFor(accent),
                            fontSize = tileLabelSizeFor(placed.item.size),
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        if (pageCount > 1 || editing) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                pageIds.forEachIndexed { index, id ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clickable { onSelectPage(id) },
                        contentAlignment = Alignment.Center,
                    ) {
                        BasicText(
                            text = if (index == pageIndex) "●" else "○",
                            style = typography.body.copy(
                                color = if (index == pageIndex) colors.accent else colors.onBackgroundSecondary,
                                fontSize = 16.sp,
                            ),
                        )
                    }
                }
                if (editing) {
                    PillButton(text = "+ page", onClick = onAddPage, width = 96.dp)
                }
            }
        }
        if (editing) {
            Column(
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(end = 12.dp, top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(
                        text = "move apps",
                        onClick = { onEditToolChange(EditTool.Move) },
                        width = 128.dp,
                        selected = editTool == EditTool.Move,
                    )
                    PillButton(
                        text = "new folder",
                        onClick = { onEditToolChange(EditTool.CreateFolder) },
                        width = 128.dp,
                        selected = editTool == EditTool.CreateFolder,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(
                        text = "tile color",
                        onClick = { onEditToolChange(EditTool.Color) },
                        width = 128.dp,
                        selected = editTool == EditTool.Color,
                    )
                }
                if (editTool == EditTool.Color) {
                    BasicText(
                        text = "choose a color, then tap tiles · tap Default to reset",
                        modifier = Modifier.padding(horizontal = 4.dp),
                        style = typography.caption.copy(color = colors.onBackgroundSecondary),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AccentPalette.families.forEach { family ->
                            val color = AccentPalette.tones.first { it.id == "${family.id}_500" }.color
                            Box(
                                Modifier.size(30.dp).clip(CircleShape).background(color)
                                    .clickable { activeFamilyId = family.id; clearTileColor = false }
                                    .then(if (family.id == activeFamilyId) Modifier.border(2.dp, colors.onBackground, CircleShape) else Modifier),
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Box(
                            modifier = Modifier.size(width = 56.dp, height = 34.dp)
                                .clip(RoundedCornerShape(10.dp)).border(1.dp, colors.onBackground.copy(alpha = .5f), RoundedCornerShape(10.dp))
                                .clickable { clearTileColor = true },
                            contentAlignment = Alignment.Center,
                        ) { BasicText("Default", style = typography.caption.copy(color = colors.onBackground)) }
                        AccentPalette.tones.filter { it.family.id == activeFamily.id }.forEach { tone ->
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(tone.color)
                                    .clickable { selectedToneId = tone.id; clearTileColor = false }
                                    .then(if (tone.id == selectedToneId && !clearTileColor) Modifier.border(2.dp, colors.onBackground, CircleShape) else Modifier),
                            )
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(text = "customize", onClick = onCustomize)
                    DoneButton(onClick = onDoneEditing)
                }
            }
        } else {
            AllAppsButton(
                onClick = onOpenApps,
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(end = 12.dp, top = 12.dp),
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FolderTilePreview(
    members: List<String>,
    tileIcon: @Composable (TileItem) -> ImageBitmap?,
    hyperMetroIcons: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (row in members.take(4).chunked(2)) {
            Row(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                for (key in row) {
                    AppIcon(
                        icon = tileIcon(TileItem(key, key, TileSize.Small)),
                        size = 24.dp,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        fillBounds = true,
                        appLabel = key,
                        hyperMetroStyle = hyperMetroIcons,
                    )
                }
                repeat(2 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        repeat((2 - members.take(4).chunked(2).size).coerceAtLeast(0)) {
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) { Spacer(Modifier.weight(1f)) }
        }
    }
}

private fun iconSizeFor(size: TileSize) = when (size) {
    TileSize.Small -> 64.dp
    TileSize.Medium -> 104.dp
    TileSize.Wide -> 128.dp
    TileSize.Large -> 216.dp
}

private fun tileInsetFor(size: TileSize) = when (size) {
    TileSize.Small -> 8.dp
    TileSize.Medium -> 12.dp
    TileSize.Wide -> 16.dp
    TileSize.Large -> 20.dp
}

private fun tileLabelSizeFor(size: TileSize) = when (size) {
    TileSize.Small -> 14.sp
    TileSize.Medium -> 16.sp
    TileSize.Wide -> 18.sp
    TileSize.Large -> 22.sp
}

private val SampleTiles = listOf(
    TileItem("phone", "Phone", TileSize.Medium),
    TileItem("messages", "Messages", TileSize.Medium, MetroAccent.Teal.color),
    TileItem("clock", "Clock", TileSize.Wide, MetroAccent.Indigo.color),
    TileItem("mail", "Mail", TileSize.Small, MetroAccent.Orange.color),
    TileItem("calendar", "Calendar", TileSize.Small, MetroAccent.Crimson.color),
    TileItem("camera", "Camera", TileSize.Small, MetroAccent.Steel.color),
    TileItem("settings", "Settings", TileSize.Small, MetroAccent.Emerald.color),
    TileItem("browser", "Browser", TileSize.Wide),
    TileItem("store", "Store", TileSize.Medium, MetroAccent.Violet.color),
    TileItem("music", "Music", TileSize.Medium, MetroAccent.Amber.color),
)

@Preview(name = "Start dark", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun StartScreenDarkPreview() {
    MetroTheme(darkTheme = true) { StartScreen() }
}

@Preview(name = "Start light", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun StartScreenLightPreview() {
    MetroTheme(darkTheme = false) { StartScreen() }
}

@Preview(name = "Start editing", showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun StartScreenEditingPreview() {
    MetroTheme(darkTheme = true) { StartScreen(editing = true) }
}
