package com.example.hypermetro.data.apps

import android.content.ComponentName
import android.content.pm.LauncherActivityInfo
import android.os.UserHandle

/**
 * Sistemin bildirdiği bir launcher girişi (uygulamanın ana ekranda görünen kapısı).
 * İş profili gibi farklı kullanıcılardaki aynı uygulama ayrı sayılır, bu yüzden [key]
 * bileşen adına ek olarak kullanıcıyı da içerir.
 */
class AppInfo(val info: LauncherActivityInfo) {
    val componentName: ComponentName = info.componentName
    val label: String = info.label?.toString().orEmpty()
    val user: UserHandle = info.user
    val key: String = componentName.flattenToString() + "#" + user.hashCode()
}
