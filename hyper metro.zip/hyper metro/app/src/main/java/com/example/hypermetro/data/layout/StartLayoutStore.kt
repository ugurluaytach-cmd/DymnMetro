package com.example.hypermetro.data.layout

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Start ekranında duran bir karonun kaydı.
 * [key] AppInfo.key ile aynı. [size] TileSize adı ("Small", "Medium"...); data katmanı
 * arayüz tiplerine bağlı kalmasın diye metin olarak tutulur.
 */
data class StoredTile(
    val key: String,
    val size: String,
    val col: Int = -1,
    val row: Int = -1,
    val folderItems: List<String> = emptyList(),
    val label: String? = null,
    val accentArgb: Int? = null,
) {
    val isFolder: Boolean get() = folderItems.isNotEmpty()
}

data class StoredPage(
    val id: String,
    val name: String,
    val tiles: List<StoredTile> = emptyList(),
)

/**
 * Start düzenini SharedPreferences içinde JSON olarak saklar. Veri küçük (en çok birkaç
 * düzine karo) olduğu için ek kütüphane gerekmiyor. Renk, konum ve grup gibi alanlar
 * Adım 8-10'da eklenince burası Room ya da DataStore'a taşınabilir.
 */
class StartLayoutStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Kayıt yoksa ya da bozuksa null döner. Çağıran taraf varsayılan düzeni kurar. */
    fun load(): List<StoredTile>? {
        val raw = prefs.getString(KEY_TILES, null) ?: return null
        return try {
            val array = JSONArray(raw)
            List(array.length()) { index ->
                val obj = array.getJSONObject(index)
                val members = obj.optJSONArray("folderItems")
                StoredTile(
                    key = obj.getString("key"),
                    size = obj.getString("size"),
                    col = obj.optInt("col", -1),
                    row = obj.optInt("row", -1),
                    folderItems = members?.let { list ->
                        List(list.length()) { memberIndex -> list.getString(memberIndex) }
                    }.orEmpty(),
                    label = obj.optString("label").takeIf { it.isNotBlank() },
                    accentArgb = if (obj.has("accentArgb")) obj.optInt("accentArgb") else null,
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Loads multiple pages, migrating the original single-page layout on first access. */
    fun loadPages(): List<StoredPage>? {
        val rawPages = prefs.getString(KEY_PAGES, null)
        if (rawPages != null) {
            return try {
                val pages = JSONArray(rawPages)
                List(pages.length()) { index ->
                    val page = pages.getJSONObject(index)
                    StoredPage(
                        id = page.getString("id"),
                        name = page.optString("name").ifBlank { "Home" },
                        tiles = parseTiles(page.optJSONArray("tiles") ?: JSONArray()),
                    )
                }.ifEmpty { null }
            } catch (e: Exception) {
                null
            }
        }
        return load()?.let { listOf(StoredPage(id = "home", name = "Home", tiles = it)) }
    }

    fun loadSelectedPageId(): String? = prefs.getString(KEY_SELECTED_PAGE, null)

    fun saveSelectedPageId(id: String) {
        prefs.edit().putString(KEY_SELECTED_PAGE, id).apply()
    }

    fun savePages(pages: List<StoredPage>) {
        val array = JSONArray()
        pages.forEach { page ->
            array.put(
                JSONObject()
                    .put("id", page.id)
                    .put("name", page.name)
                    .put("tiles", tilesToJson(page.tiles)),
            )
        }
        prefs.edit().putString(KEY_PAGES, array.toString()).apply()
    }

    fun save(tiles: List<StoredTile>) {
        prefs.edit().putString(KEY_TILES, tilesToJson(tiles).toString()).apply()
    }

    private fun parseTiles(array: JSONArray): List<StoredTile> =
        List(array.length()) { index ->
            val obj = array.getJSONObject(index)
            val members = obj.optJSONArray("folderItems")
            StoredTile(
                key = obj.getString("key"),
                size = obj.getString("size"),
                col = obj.optInt("col", -1),
                row = obj.optInt("row", -1),
                folderItems = members?.let { list ->
                    List(list.length()) { memberIndex -> list.getString(memberIndex) }
                }.orEmpty(),
                label = obj.optString("label").takeIf { it.isNotBlank() },
                accentArgb = if (obj.has("accentArgb")) obj.optInt("accentArgb") else null,
            )
        }

    private fun tilesToJson(tiles: List<StoredTile>): JSONArray {
        val array = JSONArray()
        for (tile in tiles) {
            val item = JSONObject()
                .put("key", tile.key)
                .put("size", tile.size)
                .put("col", tile.col)
                .put("row", tile.row)
            if (tile.folderItems.isNotEmpty()) item.put("folderItems", JSONArray(tile.folderItems))
            tile.label?.let { item.put("label", it) }
            tile.accentArgb?.let { item.put("accentArgb", it) }
            array.put(item)
        }
        return array
    }

    private companion object {
        const val PREFS_NAME = "start_layout"
        const val KEY_TILES = "tiles_v1"
        const val KEY_PAGES = "pages_v1"
        const val KEY_SELECTED_PAGE = "selected_page_v1"
    }
}
