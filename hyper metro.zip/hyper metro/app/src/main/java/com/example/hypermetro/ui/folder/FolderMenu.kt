package com.example.hypermetro.ui.folder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.text.BasicText
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.window.Dialog
import com.example.hypermetro.data.apps.AppInfo
import com.example.hypermetro.ui.apps.AppIcon
import com.example.hypermetro.ui.theme.MetroTheme

/** Compact Metro-style folder picker; tap outside or press back to close it. */
@Composable
fun FolderMenu(
    title: String,
    apps: List<AppInfo>,
    iconFor: @Composable (AppInfo) -> ImageBitmap?,
    onAppClick: (AppInfo) -> Unit,
    onDismiss: () -> Unit,
    hyperMetroIcons: Boolean = true,
) {
    val colors = MetroTheme.colors
    val shape = RoundedCornerShape(24.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .widthIn(min = 280.dp, max = 360.dp)
                .shadow(12.dp, shape)
                .clip(shape)
                .background(colors.surface)
                .border(BorderStroke(1.dp, colors.onBackground.copy(alpha = 0.14f)), shape)
                .padding(16.dp),
        ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    BasicText(
                        text = title,
                        style = MetroTheme.typography.pageTitle.copy(
                            color = colors.onBackground,
                            fontSize = 24.sp,
                            lineHeight = 28.sp,
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    BasicText(
                        text = "×",
                        modifier = Modifier
                            .size(44.dp)
                            .clickable(role = Role.Button, onClick = onDismiss)
                            .padding(6.dp),
                        style = MetroTheme.typography.body.copy(color = colors.onBackground),
                    )
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(apps, key = { it.key }) { app ->
                        Column(
                            modifier = Modifier
                                .clickable(role = Role.Button) { onAppClick(app) }
                                .padding(horizontal = 4.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            AppIcon(icon = iconFor(app), size = 52.dp, appLabel = app.label, hyperMetroStyle = hyperMetroIcons)
                            BasicText(
                                text = app.label,
                                style = MetroTheme.typography.caption.copy(color = colors.onBackground),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
        }
    }
}
