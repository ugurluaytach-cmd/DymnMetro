package com.example.hypermetro.ui.theme

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.produceState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import com.example.hypermetro.data.settings.WallpaperPreset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/** Lightweight, resolution-independent home wallpapers drawn in Compose. */
@Composable
fun MetroWallpaper(preset: WallpaperPreset, modifier: Modifier = Modifier, animate: Boolean = true) {
    val phaseState = if (animate && preset in setOf(WallpaperPreset.Flow, WallpaperPreset.Orbit)) {
        rememberInfiniteTransition(label = "wallpaper_${preset.name}").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing)),
            label = "wallpaper_phase",
        )
    } else remember(preset) { mutableFloatStateOf(0f) }
    val phase by phaseState
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        when (preset) {
            WallpaperPreset.System -> drawRect(
                Brush.linearGradient(listOf(Color(0xFF202B3C), Color(0xFF54687A), Color(0xFF101820))),
            )
            WallpaperPreset.Aurora -> {
                drawRect(Brush.linearGradient(listOf(Color(0xFF071522), Color(0xFF15123D), Color(0xFF070B18))))
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0x8840D6C4), Color(0x443F73C8), Color.Transparent),
                        center = Offset(w * 0.68f, h * 0.34f),
                        radius = h * 0.9f,
                    ),
                    radius = h * 0.9f,
                    center = Offset(w * 0.68f, h * 0.34f),
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0x775B4AD6), Color.Transparent),
                        center = Offset(w * 0.15f, h * 0.72f),
                        radius = h * 0.65f,
                    ),
                    radius = h * 0.65f,
                    center = Offset(w * 0.15f, h * 0.72f),
                )
            }
            WallpaperPreset.Sunset -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF28134D), Color(0xFF873D68), Color(0xFFE37852), Color(0xFF251B45))))
                val sun = Offset(w * 0.72f, h * 0.47f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFFFFE2A0), Color(0xFFFFAD72), Color(0x00FF895B)),
                        center = sun,
                        radius = h * 0.3f,
                    ),
                    radius = h * 0.3f,
                    center = sun,
                )
                val ridge = Path().apply {
                    moveTo(0f, h * 0.76f)
                    cubicTo(w * 0.28f, h * 0.62f, w * 0.38f, h * 0.88f, w * 0.62f, h * 0.72f)
                    cubicTo(w * 0.82f, h * 0.58f, w * 0.9f, h * 0.83f, w, h * 0.69f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(ridge, Color(0xCC171936))
            }
            WallpaperPreset.Ocean -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF041C35), Color(0xFF07516A), Color(0xFF06162E))))
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0x9953D7CE), Color(0x44309DAA), Color.Transparent),
                        center = Offset(w * 0.26f, h * 0.4f),
                        radius = h * 0.82f,
                    ),
                    radius = h * 0.82f,
                    center = Offset(w * 0.26f, h * 0.4f),
                )
                val wave = Path().apply {
                    moveTo(0f, h * 0.72f)
                    cubicTo(w * 0.24f, h * 0.62f, w * 0.44f, h * 0.87f, w * 0.68f, h * 0.72f)
                    cubicTo(w * 0.82f, h * 0.64f, w * 0.92f, h * 0.67f, w, h * 0.62f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(wave, Color(0x6637BBC6))
            }
            WallpaperPreset.Forest -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF071F1A), Color(0xFF176044), Color(0xFF061B18))))
                drawCircle(Color(0x5539D08B), h * .34f, Offset(w * .72f, h * .32f))
                val trees = Path().apply {
                    moveTo(0f, h * .78f); lineTo(w * .13f, h * .27f); lineTo(w * .26f, h * .78f)
                    lineTo(w * .36f, h * .42f); lineTo(w * .51f, h * .81f)
                    lineTo(w * .69f, h * .24f); lineTo(w * .88f, h * .8f); lineTo(w, h * .4f)
                    lineTo(w, h); lineTo(0f, h); close()
                }
                drawPath(trees, Color(0xCC071611))
            }
            WallpaperPreset.Graphite -> {
                drawRect(Brush.linearGradient(listOf(Color(0xFF080B10), Color(0xFF303846), Color(0xFF10131B))))
                val shard = Path().apply {
                    moveTo(w * .55f, 0f); lineTo(w, 0f); lineTo(w, h * .62f); lineTo(w * .72f, h * .48f); close()
                }
                drawPath(shard, Color(0x334E6076))
                drawCircle(Color(0x223DB7C4), h * .32f, Offset(w * .2f, h * .82f))
            }
            WallpaperPreset.Rose -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF251133), Color(0xFF8D3F72), Color(0xFFE58B91), Color(0xFF311A42))))
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFE0C5), Color(0x00FFAEBD)), Offset(w * .76f, h * .27f), h * .4f), h * .4f, Offset(w * .76f, h * .27f))
                val hill = Path().apply { moveTo(0f, h * .78f); cubicTo(w * .32f, h * .58f, w * .57f, h * .94f, w, h * .66f); lineTo(w, h); lineTo(0f, h); close() }
                drawPath(hill, Color(0xAA311638))
            }
            WallpaperPreset.Flow -> {
                drawRect(Brush.linearGradient(listOf(Color(0xFF071522), Color(0xFF10113A), Color(0xFF081D2C))))
                val x = w * (.18f + phase * .64f)
                val y = h * (.25f + .5f * kotlin.math.sin(phase * (2f * Math.PI).toFloat()))
                drawCircle(Brush.radialGradient(listOf(Color(0xAA35D8C2), Color(0x66316FC8), Color.Transparent), Offset(x, y), h * .72f), h * .72f, Offset(x, y))
                val wave = Path().apply { moveTo(0f, h * .72f); cubicTo(w * .25f, h * (.55f + phase * .12f), w * .62f, h * (.9f - phase * .12f), w, h * .65f); lineTo(w, h); lineTo(0f, h); close() }
                drawPath(wave, Color(0x5531B9CD))
            }
            WallpaperPreset.Orbit -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF080F25), Color(0xFF121D46), Color(0xFF060A17))))
                val center = Offset(w * .5f, h * .48f)
                drawCircle(Color(0x224C6AE1), h * .26f, center, style = androidx.compose.ui.graphics.drawscope.Stroke(h * .0015f))
                drawCircle(Color(0x335C83D9), h * .39f, center, style = androidx.compose.ui.graphics.drawscope.Stroke(h * .0012f))
                drawCircle(Color(0xFFFFC66D), h * .065f, center)
                val a = phase * (2f * Math.PI).toFloat()
                val planet = Offset(center.x + kotlin.math.cos(a) * h * .26f, center.y + kotlin.math.sin(a) * h * .26f)
                drawCircle(Color(0xFF73D9E8), h * .027f, planet)
                val b = -a * .62f
                drawCircle(Color(0xFFEE83B5), h * .019f, Offset(center.x + kotlin.math.cos(b) * h * .39f, center.y + kotlin.math.sin(b) * h * .39f))
            }
        }
    }
}

/** Decodes a user's persisted image URI off the UI thread and crops it to fill the screen. */
@Composable
fun CustomWallpaper(uriString: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val image by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, uriString) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(uriString)
                val resolver = context.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val target = max(context.resources.displayMetrics.widthPixels, context.resources.displayMetrics.heightPixels) * 2
                var sample = 1
                while (bounds.outWidth / sample > target || bounds.outHeight / sample > target) sample *= 2
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options)?.asImageBitmap() }
            }.getOrNull()
        }
    }
    if (image == null) {
        Box(modifier = modifier.background(Color(0xFF101820)))
    } else {
        Image(
            bitmap = image!!,
            contentDescription = null,
            modifier = modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 720)
@Composable
private fun AuroraWallpaperPreview() {
    MetroWallpaper(WallpaperPreset.Aurora, animate = false)
}
