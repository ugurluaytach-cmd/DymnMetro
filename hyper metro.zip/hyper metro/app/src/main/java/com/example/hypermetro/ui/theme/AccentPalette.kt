package com.example.hypermetro.ui.theme

import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color

data class AccentFamily(val id: String, val label: String, val hue: Float)
data class AccentTone(val id: String, val family: AccentFamily, val shade: Int, val color: Color) {
    val label: String get() = "${family.label} $shade"
}

/** Nine color families with ten readable, ordered shades each (90 choices total). */
object AccentPalette {
    val families = listOf(
        AccentFamily("blue", "Blue", 212f),
        AccentFamily("green", "Green", 142f),
        AccentFamily("red", "Red", 4f),
        AccentFamily("orange", "Orange", 27f),
        AccentFamily("yellow", "Yellow", 48f),
        AccentFamily("purple", "Purple", 270f),
        AccentFamily("pink", "Pink", 333f),
        AccentFamily("teal", "Teal", 181f),
        AccentFamily("gray", "Gray", 0f),
    )

    private val shades = listOf(50, 100, 200, 300, 400, 500, 600, 700, 800, 900)
    private val values = listOf(.98f, .95f, .90f, .83f, .75f, .66f, .57f, .48f, .39f, .30f)
    private val grayValues = listOf(.98f, .92f, .84f, .74f, .64f, .52f, .40f, .28f, .16f, .04f)
    private val saturations = listOf(.16f, .25f, .38f, .52f, .66f, .76f, .82f, .86f, .89f, .91f)
    val tones: List<AccentTone> = families.flatMap { family ->
        shades.mapIndexed { index, shade ->
            val argb = if (family.id == "gray") {
                val channel = (255f * grayValues[index]).toInt().coerceIn(0, 255)
                AndroidColor.rgb(channel, channel, channel)
            } else {
                AndroidColor.HSVToColor(floatArrayOf(family.hue, saturations[index], values[index]))
            }
            AccentTone("${family.id}_$shade", family, shade, Color(argb))
        }
    }

    fun selectedId(savedName: String): String {
        if (tones.any { it.id == savedName }) return savedName
        val legacy = mapOf(
            "Cobalt" to "blue_500", "Azure" to "blue_400", "Teal" to "teal_500",
            "Emerald" to "green_500", "Lime" to "green_700", "Amber" to "yellow_500",
            "Orange" to "orange_600", "Red" to "red_500", "Pink" to "pink_500",
            "Violet" to "purple_500", "Crimson" to "red_700", "Indigo" to "purple_600",
            "Steel" to "blue_700",
        )
        return legacy[savedName] ?: "blue_500"
    }

    fun color(savedName: String): Color = tones.first { it.id == selectedId(savedName) }.color
}
