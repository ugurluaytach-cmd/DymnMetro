package com.example.hypermetro.ui.grid

import androidx.compose.ui.graphics.Color

enum class EditTool { Move, CreateFolder, Color }

/** Karo boyutları, sütun x satır olarak. 4 sütunluk ızgara varsayımı. */
enum class TileSize(val cols: Int, val rows: Int) {
    Small(1, 1),
    Medium(2, 2),
    Wide(4, 2),
    Large(4, 4),
}

/** Düzenleme modunda boyut değiştirme sırası: küçük → orta → geniş → küçük. */
fun TileSize.nextResize(): TileSize = when (this) {
    TileSize.Small -> TileSize.Medium
    TileSize.Medium -> TileSize.Wide
    TileSize.Wide, TileSize.Large -> TileSize.Small
}

/** Izgaraya girecek karo. [accent] null ise temanın accent rengi kullanılır. */
data class TileItem(
    val id: String,
    val label: String,
    val size: TileSize,
    val accent: Color? = null,
    val gridCol: Int? = null,
    val gridRow: Int? = null,
    val folderMembers: List<String> = emptyList(),
)

/** Izgarada yeri belli olmuş karo. [col] ve [row] sol üst hücreyi gösterir. */
data class PlacedTile(
    val item: TileItem,
    val col: Int,
    val row: Int,
)

/**
 * Restores saved tile anchors first, then packs unanchored tiles into the next free slots.
 */
fun packTiles(items: List<TileItem>, columns: Int = 4): List<PlacedTile> {
    val occupied = mutableListOf<BooleanArray>()

    fun ensureRows(count: Int) {
        while (occupied.size < count) occupied.add(BooleanArray(columns))
    }

    fun fits(col: Int, row: Int, size: TileSize): Boolean {
        if (col < 0 || row < 0 || col + size.cols > columns) return false
        ensureRows(row + size.rows)
        for (r in row until row + size.rows) {
            for (c in col until col + size.cols) {
                if (occupied[r][c]) return false
            }
        }
        return true
    }

    val placed = mutableListOf<PlacedTile>()

    fun reserve(item: TileItem, col: Int, row: Int) {
        for (r in row until row + item.size.rows) {
            for (c in col until col + item.size.cols) occupied[r][c] = true
        }
        placed.add(PlacedTile(item, col, row))
    }

    val anchored = mutableSetOf<String>()
    for (item in items) {
        val col = item.gridCol
        val row = item.gridRow
        if (col != null && row != null && fits(col, row, item.size)) {
            reserve(item, col, row)
            anchored.add(item.id)
        }
    }

    for (item in items.filterNot { it.id in anchored }) {
        val size = item.size
        // Sığmayacak kadar geniş karo (cols > columns) atlanır.
        if (size.cols > columns) continue

        var row = 0
        var done = false
        while (!done) {
            for (col in 0..(columns - size.cols)) {
                if (fits(col, row, size)) {
                    reserve(item, col, row)
                    done = true
                    break
                }
            }
            if (!done) row++
        }
    }
    return placed.sortedWith(compareBy<PlacedTile> { it.row }.thenBy { it.col })
}
