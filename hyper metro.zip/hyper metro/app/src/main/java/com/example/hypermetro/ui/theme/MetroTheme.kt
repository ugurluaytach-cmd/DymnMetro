package com.example.hypermetro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

object MetroTheme {
    val colors: MetroColors
        @Composable
        @ReadOnlyComposable
        get() = LocalMetroColors.current

    val typography: MetroTypography
        @Composable
        @ReadOnlyComposable
        get() = LocalMetroTypography.current
}

/**
 * Uygulama teması. Varsayılan sistemin koyu/açık ayarını izler.
 * Monet (dinamik renk) seçeneği ayarlar ekranıyla birlikte gelecek (Adım 17).
 */
@Composable
fun MetroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    accent: Color = MetroAccent.Cobalt.color,
    overWallpaper: Boolean = false,
    tileOpacity: Float = 1f,
    content: @Composable () -> Unit,
) {
    val colors = remember(darkTheme, accent, overWallpaper) {
        if (darkTheme) {
            darkMetroColors(accent, overWallpaper)
        } else {
            lightMetroColors(accent, overWallpaper)
        }
    }
    val typography = remember { defaultMetroTypography() }

    CompositionLocalProvider(
        LocalMetroColors provides colors,
        LocalMetroTypography provides typography,
        LocalTileOpacity provides tileOpacity,
        content = content,
    )
}
