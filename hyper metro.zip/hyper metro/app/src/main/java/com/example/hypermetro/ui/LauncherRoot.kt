package com.example.hypermetro.ui

import android.content.Context
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.app.role.RoleManager
import android.os.Build
import android.provider.Settings
import android.provider.AlarmClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.core.util.Consumer
import com.example.hypermetro.data.apps.AppInfo
import com.example.hypermetro.data.apps.AppRepository
import com.example.hypermetro.data.layout.StartLayoutStore
import com.example.hypermetro.data.layout.StoredTile
import com.example.hypermetro.data.layout.StoredPage
import com.example.hypermetro.data.settings.LauncherSettings
import com.example.hypermetro.data.settings.BackgroundMode
import com.example.hypermetro.data.settings.WallpaperPreset
import com.example.hypermetro.ui.apps.AppActionsMenu
import com.example.hypermetro.ui.apps.AppEntry
import com.example.hypermetro.ui.apps.AppsScreen
import com.example.hypermetro.ui.apps.rememberAppIcon
import com.example.hypermetro.ui.components.PillButton
import com.example.hypermetro.ui.grid.TileItem
import com.example.hypermetro.ui.grid.TileSize
import com.example.hypermetro.ui.grid.EditTool
import com.example.hypermetro.ui.grid.atPosition
import com.example.hypermetro.ui.grid.pinned
import com.example.hypermetro.ui.grid.tileSizeOf
import com.example.hypermetro.ui.grid.without
import com.example.hypermetro.ui.grid.withNextSize
import com.example.hypermetro.ui.folder.FolderMenu
import com.example.hypermetro.ui.settings.SettingsScreen
import com.example.hypermetro.ui.settings.TileColorOption
import com.example.hypermetro.ui.theme.MetroTheme
import com.example.hypermetro.ui.tile.ClockTileId
import com.example.hypermetro.ui.tile.CalendarTileId
import com.example.hypermetro.ui.tile.rememberReduceMotion
import kotlinx.coroutines.launch
import java.util.UUID

private enum class Page { Start, Apps }

/** İlk açılışta Start'a konacak uygulama sayısı. Sonrası kullanıcının düzenlemesine kalır. */
private const val START_TILE_COUNT = 16

/** Turnstile dönüş açısı (derece). */
private const val TURNSTILE_DEGREES = 70f

/** Yatay kaydırmada sayfa değişimi için gereken en az mesafe. */
private const val SWIPE_THRESHOLD_DP = 80

/**
 * Ekranları ve gerçek veriyi birbirine bağlar.
 *
 * - Start ↔ Apps arası Metro turnstile geçişi (sol kenardan dönen sayfa), spring ile
 * - Start'ta sola kaydır → Apps, Apps'te sağa kaydır ya da geri tuşu → Start
 * - Start'ta karoya uzun bas → düzenleme modu (taşı, boyutlandır, kaldır); geri tuşu ya da "done" çıkar
 * - Apps'te uygulamaya uzun bas → menü (sabitle/kaldır, uygulama bilgisi, sil)
 * - Ana ekran tuşu: menüyü/düzenlemeyi kapatır, Apps açıksa Start'a döner, Start açıksa en üste kaydırır
 * - Start düzeni kaydedilir, uygulama kurulunca/silinince sıra karışmaz
 */
@Composable
fun LauncherRoot(
    settings: LauncherSettings,
    onSettingsChange: (LauncherSettings) -> Unit,
) {
    val context = LocalContext.current
    val repository = remember { AppRepository(context) }
    val layoutStore = remember { StartLayoutStore(context) }
    val scope = rememberCoroutineScope()
    val startScroll = rememberScrollState()
    val reduceMotion = rememberReduceMotion()

    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var reloadTick by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf(Page.Start) }
    var storedPages by remember { mutableStateOf(layoutStore.loadPages().orEmpty()) }
    var selectedStartPageId by remember {
        mutableStateOf(
            layoutStore.loadSelectedPageId()
                ?.takeIf { id -> storedPages.any { it.id == id } }
                ?: storedPages.firstOrNull()?.id
                ?: "home",
        )
    }
    var editing by remember { mutableStateOf(false) }
    var editTool by remember { mutableStateOf(EditTool.Move) }
    var menuApp by remember { mutableStateOf<AppEntry?>(null) }
    var pageChooserApp by remember { mutableStateOf<AppEntry?>(null) }
    var pageChooserMove by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var openFolderId by remember { mutableStateOf<String?>(null) }
    var folderNameTarget by remember { mutableStateOf<String?>(null) }
    var folderNameDraft by remember { mutableStateOf("") }
    var calendarRefresh by remember { mutableIntStateOf(0) }

    val calendarPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { calendarRefresh++ }
    val wallpaperPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
                onSettingsChange(
                    settings.copy(
                        background = BackgroundMode.Wallpaper,
                        wallpaperPreset = WallpaperPreset.System,
                        customWallpaperUri = uri.toString(),
                        savedWallpapers = (settings.savedWallpapers + uri.toString()).distinct(),
                    ),
                )
            } catch (_: SecurityException) {
                Toast.makeText(context, "Could not save photo access", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val homeRoleRequest = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { }

    val activeStartPage = storedPages.firstOrNull { it.id == selectedStartPageId }
        ?: storedPages.firstOrNull()
    val storedLayout = activeStartPage?.tiles

    fun savePages(newPages: List<StoredPage>) {
        storedPages = newPages
        layoutStore.savePages(newPages)
    }

    fun selectStartPage(id: String) {
        if (storedPages.none { it.id == id }) return
        selectedStartPageId = id
        layoutStore.saveSelectedPageId(id)
        scope.launch { startScroll.scrollTo(0) }
    }

    fun updatePageLayout(pageId: String, newLayout: List<StoredTile>) {
        savePages(storedPages.map { page ->
            if (page.id == pageId) page.copy(tiles = newLayout) else page
        })
    }

    /** Düzeni hem ekranda hem diskte günceller. */
    fun updateLayout(newLayout: List<StoredTile>) {
        activeStartPage?.let { updatePageLayout(it.id, newLayout) }
    }

    fun createStartPage(name: String = "Page ${storedPages.size + 1}"): StoredPage {
        val newPage = StoredPage(id = "page:${UUID.randomUUID()}", name = name)
        savePages(storedPages + newPage)
        selectStartPage(newPage.id)
        return newPage
    }

    // Uygulama yüklenince/silinince listeyi yeniden oku.
    DisposableEffect(repository) {
        val stop = repository.registerChangeListener { reloadTick++ }
        onDispose { stop() }
    }
    LaunchedEffect(repository, reloadTick) {
        apps = repository.loadApps()
    }

    // İlk açılışta (kayıt yokken) varsayılan düzeni kur ve kaydet.
    LaunchedEffect(apps, storedPages) {
        if (storedPages.isEmpty() && apps.isNotEmpty()) {
            val homePage = StoredPage("home", "Home", defaultLayout(apps))
            savePages(listOf(homePage))
            selectedStartPageId = homePage.id
            layoutStore.saveSelectedPageId(homePage.id)
        } else if (storedPages.isNotEmpty() && storedPages.none { it.id == selectedStartPageId }) {
            selectStartPage(storedPages.first().id)
        }
    }

    val appsByKey = remember(apps) { apps.associateBy { it.key } }
    // Kayıtlı düzen esas alınır. Silinmiş uygulamaların karoları görünmez.
    val startTiles = remember(apps, storedLayout) {
        val layout = storedLayout ?: defaultLayout(apps)
        layout.mapNotNull { stored ->
            if (stored.isFolder) {
                TileItem(
                    id = stored.key,
                    label = stored.label ?: "Folder",
                    size = tileSizeOf(stored.size),
                    accent = stored.accentArgb?.let(::Color),
                    gridCol = stored.col.takeIf { it >= 0 },
                    gridRow = stored.row.takeIf { it >= 0 },
                    folderMembers = stored.folderItems,
                )
            } else if (stored.key == ClockTileId) {
                // Canlı saat karosu bir uygulamaya bağlı değil, launcher kendisi çizer.
                TileItem(
                    ClockTileId, "Clock", tileSizeOf(stored.size),
                    accent = stored.accentArgb?.let(::Color),
                    gridCol = stored.col.takeIf { it >= 0 }, gridRow = stored.row.takeIf { it >= 0 },
                )
            } else if (stored.key == CalendarTileId) {
                TileItem(
                    CalendarTileId, "Calendar", tileSizeOf(stored.size),
                    accent = stored.accentArgb?.let(::Color),
                    gridCol = stored.col.takeIf { it >= 0 }, gridRow = stored.row.takeIf { it >= 0 },
                )
            } else {
                appsByKey[stored.key]?.let { app ->
                    TileItem(
                        app.key,
                        app.label,
                        tileSizeOf(stored.size),
                        accent = stored.accentArgb?.let(::Color),
                        gridCol = stored.col.takeIf { it >= 0 },
                        gridRow = stored.row.takeIf { it >= 0 },
                    )
                }
            }
        }
    }
    val pinnedKeys = remember(storedPages) {
        storedPages.flatMap { page ->
            page.tiles.flatMap { if (it.isFolder) it.folderItems else listOf(it.key) }
        }.toSet()
    }
    val entries = remember(apps) { apps.map { AppEntry(it.key, it.label) } }

    // Geri tuşu: sonra tanımlanan öncelikli. Menü > düzenleme > Apps sayfası.
    BackHandler(enabled = page == Page.Apps) { page = Page.Start }
    BackHandler(enabled = editing) { editing = false }
    BackHandler(enabled = menuApp != null) { menuApp = null }
    BackHandler(enabled = pageChooserApp != null) {
        pageChooserApp = null
        pageChooserMove = false
    }
    BackHandler(enabled = settingsOpen) { settingsOpen = false }
    BackHandler(enabled = openFolderId != null) { openFolderId = null }

    /** Ana ekran tuşu: önce açık olanı kapat (ayarlar, menü, düzenleme), sonra Apps → Start, sonra en üst. */
    fun onHomePressed() {
        when {
            settingsOpen -> settingsOpen = false
            openFolderId != null -> openFolderId = null
            menuApp != null -> menuApp = null
            pageChooserApp != null -> {
                pageChooserApp = null
                pageChooserMove = false
            }
            editing -> editing = false
            page == Page.Apps -> page = Page.Start
            else -> scope.launch { startScroll.animateScrollTo(0) }
        }
    }

    // Ana ekran tuşuna basılınca (singleTask → onNewIntent) onHomePressed çalışır.
    val activity = LocalActivity.current as? ComponentActivity
    DisposableEffect(activity) {
        val listener = Consumer<Intent> { intent ->
            if (intent.hasCategory(Intent.CATEGORY_HOME)) {
                onHomePressed()
            }
        }
        activity?.addOnNewIntentListener(listener)
        onDispose { activity?.removeOnNewIntentListener(listener) }
    }

    // 0 = Start görünür, 1 = Apps görünür. Değeri sadece çizim katmanında okuruz,
    // böylece animasyon sırasında ekranlar her karede yeniden oluşturulmaz.
    val transitionSpec: AnimationSpec<Float> =
        if (reduceMotion) snap() else spring(dampingRatio = 0.85f, stiffness = 380f)
    val progress = animateFloatAsState(
        targetValue = if (page == Page.Apps) 1f else 0f,
        animationSpec = transitionSpec,
        label = "pageProgress",
    )
    val showStart by remember { derivedStateOf { progress.value < 0.999f } }
    val showApps by remember { derivedStateOf { progress.value > 0.001f } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(editing) {
                // The grid owns long-press drags while editing; don't let page swipes
                // compete for the same pointer stream.
                if (editing) return@pointerInput
                val threshold = SWIPE_THRESHOLD_DP.dp.toPx()
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onHorizontalDrag = { _, dragAmount -> total += dragAmount },
                    onDragEnd = {
                        // Düzenleme ya da menü açıkken sayfa değişmez.
                        if (!editing && menuApp == null && !settingsOpen && openFolderId == null) {
                            val startPageIndex = storedPages.indexOfFirst { it.id == selectedStartPageId }
                                .coerceAtLeast(0)
                            if (page == Page.Start && total < -threshold) {
                                if (startPageIndex < storedPages.lastIndex) {
                                    selectStartPage(storedPages[startPageIndex + 1].id)
                                } else {
                                    page = Page.Apps
                                }
                            } else if (page == Page.Start && total > threshold && startPageIndex > 0) {
                                selectStartPage(storedPages[startPageIndex - 1].id)
                            } else if (page == Page.Apps && total > threshold) {
                                page = Page.Start
                                if (storedPages.isNotEmpty()) selectStartPage(storedPages[startPageIndex].id)
                            }
                        }
                    },
                )
            },
    ) {
        if (showStart) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .turnstile(
                        angle = { -progress.value * TURNSTILE_DEGREES },
                        opacity = { 1f - progress.value },
                    ),
            ) {
                StartScreen(
                    items = startTiles,
                    columns = settings.tileColumns,
                    hyperMetroIcons = settings.hyperMetroIcons,
                    tileIcon = { item ->
                        appsByKey[item.id]?.let { rememberAppIcon(repository, it) }
                    },
                    editing = editing,
                    editTool = editTool,
                    pageIndex = storedPages.indexOfFirst { it.id == selectedStartPageId }.coerceAtLeast(0),
                    pageCount = storedPages.size,
                    pageIds = storedPages.map { it.id },
                    onSelectPage = ::selectStartPage,
                    onAddPage = { createStartPage() },
                    onTileTap = { item ->
                        if (item.folderMembers.isNotEmpty()) {
                            openFolderId = item.id
                        } else if (item.id == ClockTileId) {
                            openClockApp(context)
                        } else {
                            appsByKey[item.id]?.let(repository::launch)
                        }
                    },
                    onTileLongPress = {
                        editTool = EditTool.Move
                        editing = true
                    },
                    onUnpin = { item -> storedLayout?.let { updateLayout(it.without(item.id)) } },
                    onResize = { item -> storedLayout?.let { updateLayout(it.withNextSize(item.id)) } },
                    onTileDrop = { from, target, col, row, fromCol, fromRow ->
                        val newFolderId = updateTileAfterDrop(
                            layout = storedLayout.orEmpty(),
                            fromId = from,
                            targetId = target,
                            col = col,
                            row = row,
                            fromCol = fromCol,
                            fromRow = fromRow,
                            createFolderMode = editTool == EditTool.CreateFolder,
                            onUpdate = ::updateLayout,
                        )
                        if (newFolderId != null) {
                            folderNameTarget = newFolderId
                            folderNameDraft = "Folder"
                        }
                    },
                    onTileColorChange = { id, color ->
                        updateLayout(storedLayout.orEmpty().map { tile ->
                            if (tile.key == id) tile.copy(accentArgb = color?.toArgb()) else tile
                        })
                    },
                    onEditToolChange = { editTool = it },
                    onOpenApps = { page = Page.Apps },
                    onDoneEditing = { editing = false },
                    onCustomize = {
                        editing = false
                        settingsOpen = true
                    },
                    scrollState = startScroll,
                    calendarRefresh = calendarRefresh,
                )
            }
        }
        if (showApps) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .turnstile(
                        angle = { (1f - progress.value) * TURNSTILE_DEGREES },
                        opacity = { progress.value },
                    ),
            ) {
                AppsScreen(
                    entries = entries,
                    hyperMetroIcons = settings.hyperMetroIcons,
                    iconFor = { entry ->
                        appsByKey[entry.key]?.let { rememberAppIcon(repository, it) }
                    },
                    onAppTap = { entry -> appsByKey[entry.key]?.let(repository::launch) },
                    onAppLongPress = { entry -> menuApp = entry },
                )
            }
        }

        menuApp?.let { entry ->
            val app = appsByKey[entry.key]
            val isPinned = entry.key in pinnedKeys
            AppActionsMenu(
                title = entry.label,
                pinned = isPinned,
                onPinToggle = {
                    if (isPinned) {
                        savePages(storedPages.map { startPage ->
                            startPage.copy(tiles = removeAppFromLayout(startPage.tiles, entry.key))
                        })
                        Toast.makeText(context, "Unpinned from start", Toast.LENGTH_SHORT).show()
                        menuApp = null
                    } else {
                        pageChooserMove = false
                        pageChooserApp = entry
                        menuApp = null
                    }
                },
                onMoveToPage = if (isPinned && storedPages.size > 1) {
                    {
                        pageChooserMove = true
                        pageChooserApp = entry
                        menuApp = null
                    }
                } else null,
                onAppInfo = {
                    app?.let(repository::openAppInfo)
                    menuApp = null
                },
                onUninstall = {
                    app?.let(repository::uninstall)
                    menuApp = null
                },
                onDismiss = { menuApp = null },
            )
        }

        pageChooserApp?.let { entry ->
            val colors = MetroTheme.colors
            val shape = RoundedCornerShape(24.dp)
            Dialog(onDismissRequest = {
                pageChooserApp = null
                pageChooserMove = false
            }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(colors.surface)
                        .border(1.dp, colors.onBackground.copy(alpha = 0.16f), shape)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    BasicText(
                        text = if (pageChooserMove) {
                            "Move ${entry.label} to which page?"
                        } else {
                            "Add ${entry.label} to which page?"
                        },
                        style = MetroTheme.typography.pageTitle.copy(
                            color = colors.onBackground,
                            fontSize = 22.sp,
                            lineHeight = 26.sp,
                        ),
                    )
                    storedPages.forEachIndexed { index, startPage ->
                        PageChoice(
                            title = "${index + 1}. ${startPage.name}",
                            subtitle = "${startPage.tiles.size} items",
                            onClick = {
                                val moving = pageChooserMove
                                val pagesWithoutApp = if (moving) {
                                    storedPages.map { page ->
                                        page.copy(tiles = removeAppFromLayout(page.tiles, entry.key))
                                    }
                                } else storedPages
                                savePages(pagesWithoutApp.map { page ->
                                    if (page.id == startPage.id) {
                                        page.copy(tiles = page.tiles.pinned(entry.key))
                                    } else page
                                })
                                selectStartPage(startPage.id)
                                pageChooserApp = null
                                pageChooserMove = false
                                Toast.makeText(
                                    context,
                                    if (moving) "Moved to ${startPage.name}" else "Pinned to ${startPage.name}",
                                    Toast.LENGTH_SHORT,
                                ).show()
                            },
                        )
                    }
                    PageChoice(
                        title = "+ New page",
                        subtitle = if (pageChooserMove) "Move this app to a new page" else "Create a page and add this app",
                        onClick = {
                            val newPage = StoredPage(
                                id = "page:${UUID.randomUUID()}",
                                name = "Page ${storedPages.size + 1}",
                                tiles = listOf(StoredTile(entry.key, TileSize.Small.name)),
                            )
                            val pagesWithoutApp = if (pageChooserMove) {
                                storedPages.map { page ->
                                    page.copy(tiles = removeAppFromLayout(page.tiles, entry.key))
                                }
                            } else storedPages
                            savePages(pagesWithoutApp + newPage)
                            selectStartPage(newPage.id)
                            pageChooserApp = null
                            pageChooserMove = false
                        },
                    )
                }
            }
        }

        openFolderId?.let { folderId ->
            val folder = storedLayout.orEmpty().firstOrNull { it.key == folderId && it.isFolder }
            if (folder != null) {
                val folderApps = folder.folderItems.mapNotNull(appsByKey::get)
                FolderMenu(
                    title = folder.label ?: "Folder",
                    apps = folderApps,
                    iconFor = { app -> rememberAppIcon(repository, app) },
                    hyperMetroIcons = settings.hyperMetroIcons,
                    onAppClick = { app ->
                        repository.launch(app)
                        openFolderId = null
                    },
                    onDismiss = { openFolderId = null },
                )
            }
        }

        folderNameTarget?.let { folderId ->
            val colors = MetroTheme.colors
            val shape = RoundedCornerShape(24.dp)
            Dialog(onDismissRequest = { folderNameTarget = null }) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(colors.surface)
                        .border(1.dp, colors.onBackground.copy(alpha = 0.16f), shape)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    BasicText(
                        text = "Name folder",
                        style = MetroTheme.typography.pageTitle.copy(
                            color = colors.onBackground,
                            fontSize = 24.sp,
                            lineHeight = 28.sp,
                        ),
                    )
                    BasicTextField(
                        value = folderNameDraft,
                        onValueChange = { folderNameDraft = it },
                        singleLine = true,
                        textStyle = MetroTheme.typography.body.copy(color = colors.onBackground),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, colors.onBackground.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        decorationBox = { innerTextField ->
                            Box {
                                if (folderNameDraft.isEmpty()) {
                                    BasicText(
                                        text = "Folder name",
                                        style = MetroTheme.typography.body.copy(color = colors.onBackgroundSecondary),
                                    )
                                }
                                innerTextField()
                            }
                        },
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        PillButton(
                            text = "cancel",
                            onClick = { folderNameTarget = null },
                            width = 96.dp,
                        )
                        Box(Modifier.padding(start = 8.dp)) {
                            PillButton(
                                text = "save",
                                onClick = {
                                    val label = folderNameDraft.trim().ifBlank { "Folder" }
                                    updateLayout(storedLayout.orEmpty().map { tile ->
                                        if (tile.key == folderId) tile.copy(label = label) else tile
                                    })
                                    folderNameTarget = null
                                },
                                width = 96.dp,
                                selected = true,
                            )
                        }
                    }
                }
            }
        }

        if (settingsOpen) {
            SettingsScreen(
                settings = settings,
                onChange = onSettingsChange,
                onClose = { settingsOpen = false },
                onChooseWallpaper = { wallpaperPicker.launch(arrayOf("image/*")) },
                tileColorOptions = storedPages.flatMap { startPage ->
                    startPage.tiles.mapNotNull { tile ->
                        val label = when {
                            tile.isFolder -> tile.label ?: "Folder"
                            tile.key == ClockTileId -> "Clock"
                            tile.key == CalendarTileId -> "Calendar"
                            else -> appsByKey[tile.key]?.label ?: return@mapNotNull null
                        }
                        TileColorOption(
                            pageId = startPage.id,
                            key = tile.key,
                            label = "${startPage.name} · $label",
                            color = tile.accentArgb?.let(::Color),
                        )
                    }
                },
                onTileColorChange = { pageId, key, color ->
                    updatePageLayout(pageId, storedPages.firstOrNull { it.id == pageId }
                        ?.tiles.orEmpty().map { tile ->
                            if (tile.key == key) tile.copy(accentArgb = color?.toArgb()) else tile
                        })
                },
                onAddClockTile = {
                    val layout = storedLayout.orEmpty()
                    if (layout.any { it.key == ClockTileId }) {
                        Toast.makeText(context, "Clock tile is already on start", Toast.LENGTH_SHORT).show()
                    } else {
                        updateLayout(layout.pinned(ClockTileId, TileSize.Wide))
                        Toast.makeText(context, "Clock tile added to start", Toast.LENGTH_SHORT).show()
                    }
                },
                onAddCalendarTile = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) !=
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                    }
                    val layout = storedLayout.orEmpty()
                    if (layout.any { it.key == CalendarTileId }) {
                        Toast.makeText(context, "Calendar tile is already on start", Toast.LENGTH_SHORT).show()
                    } else {
                        updateLayout(layout.pinned(CalendarTileId, TileSize.Wide))
                        Toast.makeText(context, "Calendar tile added to start", Toast.LENGTH_SHORT).show()
                    }
                },
                onSetDefaultLauncher = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val roleManager = context.getSystemService(RoleManager::class.java)
                        if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                            homeRoleRequest.launch(
                                roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME),
                            )
                        }
                    } else {
                        context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                    }
                },
            )
        }
    }
}

/** Sol kenarı eksen alıp sayfayı Y ekseninde çevirir (Metro turnstile). */
private fun Modifier.turnstile(angle: () -> Float, opacity: () -> Float): Modifier =
    graphicsLayer {
        transformOrigin = TransformOrigin(0f, 0.5f)
        rotationY = angle()
        this.alpha = opacity()
        cameraDistance = 16f * density
    }

@Composable
private fun PageChoice(title: String, subtitle: String, onClick: () -> Unit) {
    val colors = MetroTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(colors.background.copy(alpha = 0.55f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            BasicText(title, style = MetroTheme.typography.body.copy(color = colors.onBackground))
            BasicText(
                subtitle,
                style = MetroTheme.typography.caption.copy(color = colors.onBackgroundSecondary),
            )
        }
    }
}

/** Geçici varsayılan düzen: üstte geniş saat karosu, sonra ilk ikisi orta boy, kalanı küçük. */
private fun defaultLayout(apps: List<AppInfo>): List<StoredTile> =
    listOf(StoredTile(ClockTileId, TileSize.Wide.name)) +
        apps.take(START_TILE_COUNT).mapIndexed { index, app ->
            val size = if (index < 2) TileSize.Medium else TileSize.Small
            StoredTile(app.key, size.name)
        }

private fun updateTileAfterDrop(
    layout: List<StoredTile>,
    fromId: String,
    targetId: String?,
    col: Int,
    row: Int,
    fromCol: Int,
    fromRow: Int,
    createFolderMode: Boolean,
    onUpdate: (List<StoredTile>) -> Unit,
): String? {
    val source = layout.firstOrNull { it.key == fromId } ?: return null
    val target = targetId?.let { id -> layout.firstOrNull { it.key == id } }
    val sourceIsLive = source.key == ClockTileId || source.key == CalendarTileId
    val targetIsLive = target?.key == ClockTileId || target?.key == CalendarTileId

    if (target != null && !sourceIsLive && target.key != source.key && !targetIsLive && createFolderMode) {
        val sourceMembers = if (source.isFolder) source.folderItems else listOf(source.key)
        if (target.isFolder) {
            val merged = (target.folderItems + sourceMembers).distinct()
            val result = layout
                .filterNot { it.key == source.key }
                .map { tile ->
                    if (tile.key == target.key) tile.copy(folderItems = merged) else tile
                }
            onUpdate(result)
            return null
        }

        val targetMembers = if (target.isFolder) target.folderItems else listOf(target.key)
        val members = (targetMembers + sourceMembers).distinct()
        val folder = if (source.isFolder) {
            source.copy(
                col = target.col.takeIf { it >= 0 } ?: col,
                row = target.row.takeIf { it >= 0 } ?: row,
                folderItems = members,
            )
        } else {
            StoredTile(
                key = "folder:${UUID.randomUUID()}",
                size = TileSize.Medium.name,
                col = target.col.takeIf { it >= 0 } ?: col,
                row = target.row.takeIf { it >= 0 } ?: row,
                folderItems = members,
                label = "Folder",
            )
        }
        val insertAt = layout.indexOf(target).coerceAtLeast(0)
        val result = layout.filterNot { it.key == source.key || it.key == target.key }.toMutableList()
        result.add(insertAt.coerceIn(0, result.size), folder)
        onUpdate(result)
        return folder.key
    }

    if (target != null && !sourceIsLive && target.key != source.key && !targetIsLive) {
        // Normal move mode swaps positions. Folder creation is an explicit separate tool.
        onUpdate(layout.map { tile ->
            when (tile.key) {
                source.key -> tile.copy(col = col, row = row)
                target.key -> tile.copy(col = fromCol, row = fromRow)
                else -> tile
            }
        })
        return null
    }

    if (createFolderMode && targetIsLive) return null

    onUpdate(layout.atPosition(fromId, col, row))
    return null
}

private fun removeAppFromLayout(layout: List<StoredTile>, appKey: String): List<StoredTile> {
    val parent = layout.firstOrNull { appKey in it.folderItems } ?: return layout.without(appKey)
    val remaining = parent.folderItems.filterNot { it == appKey }
    return if (remaining.size <= 1) {
        layout.without(parent.key) + remaining.map { key ->
            StoredTile(key, TileSize.Small.name, col = parent.col, row = parent.row)
        }
    } else {
        layout.map { tile -> if (tile.key == parent.key) tile.copy(folderItems = remaining) else tile }
    }
}

/** Sistemin saat/alarm uygulamasını açar. Bulunamazsa sessiz geçer. */
private fun openClockApp(context: Context) {
    try {
        context.startActivity(
            Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (e: Exception) {
        // Cihazda saat uygulaması yoksa ya da açılamıyorsa bir şey yapma.
    }
}
