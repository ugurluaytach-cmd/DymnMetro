# HyperMetro

**A Metro-inspired Android launcher with its own tile layout, colors, wallpapers, and icon style.** HyperMetro reimagines the glanceable tile home screen for Android instead of trying to reproduce another launcher pixel for pixel.

> An independent community project. It is not affiliated with, endorsed by, or sponsored by Microsoft, Google, or any phone manufacturer. “Metro” describes the visual inspiration only; the project uses its own name and implementation.

## Preview

![HyperMetro tile editing screen](docs/screenshots/hypermetro-tile-editor.png)

*Tile editing screen captured from a project-owner test build. App icons shown are supplied by Android/the installed apps.*

## What it does

- Replaces the Android Home screen when selected as the default launcher.
- Lets you pin apps to a tiled start screen, resize and rearrange tiles, and organize apps in folders.
- Supports multiple start pages and choosing a destination page when pinning or moving an app.
- Includes an app drawer with search and alphabetical navigation.
- Offers Android-provided app icons or a built-in HyperMetro line-icon style.
- Provides color, transparency, theme, wallpaper, and grid-column customization.
- Includes optional clock and calendar tiles.

Per-tile colors and some editing flows are still being verified on real devices. Check [ROADMAP.md](ROADMAP.md) for current status, priorities, and known follow-up work. The project is in active development; this is not a finished Play Store release.

## Build

### Requirements

- Android Studio with Android SDK Platform 36 and Build Tools 36.1.0
- JDK 21 (the Gradle daemon toolchain is configured for Java 21)
- Android 8.0 (API 26) or newer to install the app

From the project directory on Windows:

```powershell
\.\gradlew.bat assembleDebug
```

On macOS or Linux:

```sh
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`. Install it on a test device, open HyperMetro, and choose it as the default Home app in Android settings to try it as a launcher. You can also run it as a regular app without changing the default launcher.

## Project notes

- The current Android application ID is `com.example.hypermetro`; choose a permanent ID before a public store release.
- The launcher provides the Home screen and app drawer. Android remains responsible for launching apps and for system-managed app windows.
- Desktop mode is a later roadmap item; phone and tablet fundamentals come first.
- `docs/DESIGN-LANGUAGE.md` contains draft visual guidance and can differ from the current implementation.

## Inspiration and credits

HyperMetro takes inspiration from the general idea of a customizable, glanceable tile-based home screen associated with the Metro design era. Its name, source code, interface, and built-in icon drawings are developed for this project. No Microsoft or Apple logos or proprietary icon packs are included. Native icons visible in screenshots come from the Android apps installed on the capture device.

This source tree includes [`LICENSE-DymnMetro-MIT`](LICENSE-DymnMetro-MIT), which credits Dima / Dymn Studio. Preserve that license and attribution when redistributing the covered code. Review file history and third-party asset licenses before publishing a modified distribution; do not present upstream work as solely authored by HyperMetro.

## Roadmap

See [ROADMAP.md](ROADMAP.md) for the prioritized plan: reliability fixes, daily launcher basics, visual consistency, optional advanced features, beta readiness, and desktop mode later.

## Contributing

Bug reports, device-specific findings, and focused pull requests are welcome. Please include Android version, device model, steps to reproduce, and a screenshot or screen recording when useful. Avoid submitting screenshots that expose personal notifications, contacts, or other private information.
